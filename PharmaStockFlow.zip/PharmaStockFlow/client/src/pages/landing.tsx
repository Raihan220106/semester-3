import { Button } from "@/components/ui/button";
import { Package, ShieldCheck, FileText, AlertCircle } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-8">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-primary/10 mb-6">
              <Package className="w-10 h-10 text-primary" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
              Pharmacy Inventory System
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Sistem manajemen inventory farmasi yang modern dan efisien. 
              Kelola stok obat, transaksi, dan laporan dengan mudah.
            </p>
            <Button 
              size="lg" 
              className="text-lg px-8"
              onClick={() => window.location.href = "/api/login"}
              data-testid="button-login"
            >
              Masuk ke Sistem
            </Button>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mt-16">
            <div className="p-6 rounded-md bg-card border border-card-border hover-elevate">
              <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4 mx-auto">
                <ShieldCheck className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Role-Based Access</h3>
              <p className="text-sm text-muted-foreground">
                Kontrol akses berbasis role untuk Admin dan Staff dengan keamanan terjamin
              </p>
            </div>

            <div className="p-6 rounded-md bg-card border border-card-border hover-elevate">
              <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4 mx-auto">
                <AlertCircle className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Reminder Stok</h3>
              <p className="text-sm text-muted-foreground">
                Notifikasi otomatis ketika stok obat menipis untuk mencegah kekosongan
              </p>
            </div>

            <div className="p-6 rounded-md bg-card border border-card-border hover-elevate">
              <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4 mx-auto">
                <FileText className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Laporan Lengkap</h3>
              <p className="text-sm text-muted-foreground">
                Export laporan dalam format PDF dan Excel untuk dokumentasi
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
