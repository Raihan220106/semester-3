import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, TrendingDown, DollarSign, ShoppingCart, AlertTriangle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import type { Medicine, Transaction } from "@shared/schema";

export default function Dashboard() {
  const { data: medicines, isLoading: loadingMedicines } = useQuery<Medicine[]>({
    queryKey: ["/api/medicines"],
  });

  const { data: transactions, isLoading: loadingTransactions } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  const { data: lowStockMedicines } = useQuery<Medicine[]>({
    queryKey: ["/api/medicines/low-stock"],
  });

  const totalMedicines = medicines?.length || 0;
  const totalValue = medicines?.reduce((sum, med) => sum + (parseFloat(med.price) * med.stock), 0) || 0;
  const lowStockCount = lowStockMedicines?.length || 0;
  const recentTransactions = transactions?.slice(0, 5) || [];

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
        <p className="text-muted-foreground">Ringkasan inventory apotek Anda</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Obat</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loadingMedicines ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <>
                <div className="text-2xl font-bold font-mono" data-testid="stat-total-medicines">{totalMedicines}</div>
                <p className="text-xs text-muted-foreground mt-1">Jenis obat tersedia</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Stok Menipis</CardTitle>
            <TrendingDown className="h-4 w-4 text-chart-3" />
          </CardHeader>
          <CardContent>
            {loadingMedicines ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <>
                <div className="text-2xl font-bold font-mono text-chart-3" data-testid="stat-low-stock">
                  {lowStockCount}
                </div>
                <p className="text-xs text-muted-foreground mt-1">Perlu restock segera</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Nilai Inventory</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loadingMedicines ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <>
                <div className="text-2xl font-bold font-mono" data-testid="stat-inventory-value">
                  Rp {totalValue.toLocaleString('id-ID')}
                </div>
                <p className="text-xs text-muted-foreground mt-1">Total nilai stok</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Transaksi</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loadingTransactions ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <>
                <div className="text-2xl font-bold font-mono" data-testid="stat-transactions">
                  {transactions?.length || 0}
                </div>
                <p className="text-xs text-muted-foreground mt-1">Total transaksi</p>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {lowStockCount > 0 && (
        <Card className="border-chart-3/20 bg-chart-3/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-chart-3">
              <AlertTriangle className="h-5 w-5" />
              Peringatan Stok Menipis
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {lowStockMedicines?.slice(0, 5).map((medicine) => (
                <div
                  key={medicine.id}
                  className="flex items-center justify-between p-3 rounded-md bg-background/50 border border-border"
                  data-testid={`alert-medicine-${medicine.id}`}
                >
                  <div className="flex-1">
                    <p className="font-medium">{medicine.name}</p>
                    <p className="text-sm text-muted-foreground">Kode: {medicine.code}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-mono font-semibold text-chart-3">
                      Stok: {medicine.stock} {medicine.unit}
                    </p>
                    <p className="text-xs text-muted-foreground">Min: {medicine.minStock}</p>
                  </div>
                </div>
              ))}
              {lowStockCount > 5 && (
                <Link href="/medicines">
                  <a className="text-sm text-primary hover:underline block text-center pt-2">
                    Lihat {lowStockCount - 5} obat lainnya →
                  </a>
                </Link>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Transaksi Terbaru</CardTitle>
        </CardHeader>
        <CardContent>
          {loadingTransactions ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : recentTransactions.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">Belum ada transaksi</p>
          ) : (
            <div className="space-y-3">
              {recentTransactions.map((transaction: any) => (
                <div
                  key={transaction.id}
                  className="flex items-center justify-between p-3 rounded-md border border-border hover-elevate"
                  data-testid={`transaction-${transaction.id}`}
                >
                  <div className="flex items-center gap-3 flex-1">
                    <Badge variant={transaction.type === "in" ? "default" : "secondary"}>
                      {transaction.type === "in" ? "Masuk" : "Keluar"}
                    </Badge>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{transaction.medicine?.name || "-"}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(transaction.transactionDate).toLocaleDateString('id-ID')}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-mono font-semibold">
                      {transaction.type === "in" ? "+" : "-"}{transaction.quantity}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
