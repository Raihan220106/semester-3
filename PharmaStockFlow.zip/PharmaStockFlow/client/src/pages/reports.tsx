import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { FileDown, FileSpreadsheet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { Medicine, Transaction } from "@shared/schema";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import { Badge } from "@/components/ui/badge";

export default function Reports() {
  const [reportType, setReportType] = useState<string>("inventory");

  const { data: medicines } = useQuery<Medicine[]>({
    queryKey: ["/api/medicines"],
  });

  const { data: transactions } = useQuery<any[]>({
    queryKey: ["/api/transactions"],
  });

  const generatePDF = () => {
    const doc = new jsPDF();
    
    doc.setFontSize(18);
    doc.text("Pharmacy Inventory Report", 14, 20);
    doc.setFontSize(10);
    doc.text(`Generated: ${new Date().toLocaleDateString('id-ID')}`, 14, 28);

    if (reportType === "inventory") {
      const tableData = medicines?.map((med) => [
        med.code,
        med.name,
        med.stock.toString(),
        med.unit,
        `Rp ${parseFloat(med.price).toLocaleString('id-ID')}`,
        `Rp ${(parseFloat(med.price) * med.stock).toLocaleString('id-ID')}`,
        med.stock <= med.minStock ? "Low" : "OK",
      ]) || [];

      autoTable(doc, {
        startY: 35,
        head: [["Kode", "Nama Obat", "Stok", "Satuan", "Harga", "Total Nilai", "Status"]],
        body: tableData,
        theme: "striped",
        headStyles: { fillColor: [34, 139, 34] },
      });

      const totalValue = medicines?.reduce((sum, med) => sum + (parseFloat(med.price) * med.stock), 0) || 0;
      const finalY = (doc as any).lastAutoTable.finalY || 35;
      doc.setFontSize(12);
      doc.text(`Total Nilai Inventory: Rp ${totalValue.toLocaleString('id-ID')}`, 14, finalY + 10);
    } else {
      const tableData = transactions?.map((trans) => [
        new Date(trans.transactionDate).toLocaleDateString('id-ID'),
        trans.type === "in" ? "Masuk" : "Keluar",
        trans.medicine?.name || "-",
        trans.quantity.toString(),
        trans.type === "in" ? (trans.supplier?.name || "-") : (trans.patientName || "-"),
        trans.notes || "-",
      ]) || [];

      autoTable(doc, {
        startY: 35,
        head: [["Tanggal", "Tipe", "Obat", "Jumlah", "Supplier/Pasien", "Catatan"]],
        body: tableData,
        theme: "striped",
        headStyles: { fillColor: [34, 139, 34] },
      });
    }

    doc.save(`pharmacy-report-${reportType}-${Date.now()}.pdf`);
  };

  const generateExcel = () => {
    let data: any[] = [];
    let filename = "";

    if (reportType === "inventory") {
      data = medicines?.map((med) => ({
        Kode: med.code,
        "Nama Obat": med.name,
        Stok: med.stock,
        Satuan: med.unit,
        Harga: parseFloat(med.price),
        "Total Nilai": parseFloat(med.price) * med.stock,
        Status: med.stock <= med.minStock ? "Low Stock" : "OK",
      })) || [];
      filename = `inventory-report-${Date.now()}.xlsx`;
    } else {
      data = transactions?.map((trans) => ({
        Tanggal: new Date(trans.transactionDate).toLocaleDateString('id-ID'),
        Tipe: trans.type === "in" ? "Masuk" : "Keluar",
        Obat: trans.medicine?.name || "-",
        Jumlah: trans.quantity,
        "Supplier/Pasien": trans.type === "in" ? (trans.supplier?.name || "-") : (trans.patientName || "-"),
        Catatan: trans.notes || "-",
      })) || [];
      filename = `transactions-report-${Date.now()}.xlsx`;
    }

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Report");
    XLSX.writeFile(wb, filename);
  };

  const getReportStats = () => {
    if (reportType === "inventory") {
      const totalValue = medicines?.reduce((sum, med) => sum + (parseFloat(med.price) * med.stock), 0) || 0;
      const lowStockCount = medicines?.filter((med) => med.stock <= med.minStock).length || 0;
      return { totalItems: medicines?.length || 0, totalValue, lowStockCount };
    } else {
      const stockIn = transactions?.filter((t) => t.type === "in").length || 0;
      const stockOut = transactions?.filter((t) => t.type === "out").length || 0;
      return { totalTransactions: transactions?.length || 0, stockIn, stockOut };
    }
  };

  const stats = getReportStats();

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Laporan</h1>
        <p className="text-muted-foreground">Export laporan dalam format PDF atau Excel</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Pilih Jenis Laporan</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Select value={reportType} onValueChange={setReportType}>
            <SelectTrigger data-testid="select-report-type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="inventory">Laporan Inventory</SelectItem>
              <SelectItem value="transactions">Laporan Transaksi</SelectItem>
            </SelectContent>
          </Select>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 rounded-md bg-muted/50">
            {reportType === "inventory" ? (
              <>
                <div>
                  <p className="text-sm text-muted-foreground">Total Obat</p>
                  <p className="text-2xl font-bold font-mono">{stats.totalItems}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Nilai Inventory</p>
                  <p className="text-2xl font-bold font-mono">Rp {stats.totalValue?.toLocaleString('id-ID')}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Stok Menipis</p>
                  <p className="text-2xl font-bold font-mono text-chart-3">{stats.lowStockCount}</p>
                </div>
              </>
            ) : (
              <>
                <div>
                  <p className="text-sm text-muted-foreground">Total Transaksi</p>
                  <p className="text-2xl font-bold font-mono">{stats.totalTransactions}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Stok Masuk</p>
                  <p className="text-2xl font-bold font-mono text-chart-1">{stats.stockIn}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Stok Keluar</p>
                  <p className="text-2xl font-bold font-mono text-chart-2">{stats.stockOut}</p>
                </div>
              </>
            )}
          </div>

          <div className="flex gap-3 pt-4">
            <Button onClick={generatePDF} data-testid="button-export-pdf">
              <FileDown className="w-4 h-4 mr-2" />
              Export PDF
            </Button>
            <Button variant="outline" onClick={generateExcel} data-testid="button-export-excel">
              <FileSpreadsheet className="w-4 h-4 mr-2" />
              Export Excel
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Preview Data</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {reportType === "inventory" ? (
              medicines?.slice(0, 10).map((med) => (
                <div
                  key={med.id}
                  className="flex items-center justify-between p-3 rounded-md border border-border"
                  data-testid={`preview-medicine-${med.id}`}
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{med.name}</p>
                    <p className="text-sm text-muted-foreground">Kode: {med.code}</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="font-mono font-semibold">
                        {med.stock} {med.unit}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Rp {parseFloat(med.price).toLocaleString('id-ID')}
                      </p>
                    </div>
                    {med.stock <= med.minStock && (
                      <Badge variant="secondary">Low</Badge>
                    )}
                  </div>
                </div>
              ))
            ) : (
              transactions?.slice(0, 10).map((trans: any) => (
                <div
                  key={trans.id}
                  className="flex items-center justify-between p-3 rounded-md border border-border"
                  data-testid={`preview-transaction-${trans.id}`}
                >
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <Badge variant={trans.type === "in" ? "default" : "secondary"}>
                      {trans.type === "in" ? "Masuk" : "Keluar"}
                    </Badge>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{trans.medicine?.name || "-"}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(trans.transactionDate).toLocaleDateString('id-ID')}
                      </p>
                    </div>
                  </div>
                  <p className="font-mono font-semibold">
                    {trans.type === "in" ? "+" : "-"}{trans.quantity}
                  </p>
                </div>
              ))
            )}
            {(reportType === "inventory" && medicines && medicines.length > 10) ||
             (reportType === "transactions" && transactions && transactions.length > 10) ? (
              <p className="text-sm text-muted-foreground text-center pt-2">
                ... dan {reportType === "inventory" ? medicines!.length - 10 : transactions!.length - 10} data lainnya
              </p>
            ) : null}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
