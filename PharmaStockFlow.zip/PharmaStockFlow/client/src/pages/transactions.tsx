import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Plus, ArrowDown, ArrowUp, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertTransactionSchema } from "@shared/schema";
import type { Transaction, Medicine, Supplier, InsertTransaction } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useAuth } from "@/hooks/useAuth";

export default function Transactions() {
  const [open, setOpen] = useState(false);
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const { toast } = useToast();
  const { user } = useAuth();

  const { data: transactions, isLoading } = useQuery<any[]>({
    queryKey: ["/api/transactions"],
  });

  const { data: medicines } = useQuery<Medicine[]>({
    queryKey: ["/api/medicines"],
  });

  const { data: suppliers } = useQuery<Supplier[]>({
    queryKey: ["/api/suppliers"],
  });

  const form = useForm<InsertTransaction>({
    resolver: zodResolver(insertTransactionSchema),
    defaultValues: {
      type: "in",
      medicineId: 0,
      quantity: 1,
      userId: user?.id || "",
      supplierId: undefined,
      patientName: "",
      notes: "",
      transactionDate: new Date(),
    },
  });

  const transactionType = form.watch("type");

  const createMutation = useMutation({
    mutationFn: async (data: InsertTransaction) => {
      await apiRequest("POST", "/api/transactions", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/medicines"] });
      toast({ title: "Berhasil", description: "Transaksi berhasil dicatat" });
      setOpen(false);
      form.reset();
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const onSubmit = (data: InsertTransaction) => {
    createMutation.mutate({
      ...data,
      userId: user?.id || "",
    });
  };

  const filteredTransactions = transactions?.filter((t) => {
    if (typeFilter === "all") return true;
    return t.type === typeFilter;
  });

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold mb-2">Transaksi</h1>
          <p className="text-muted-foreground">Riwayat stok masuk dan keluar</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-transaction">
              <Plus className="w-4 h-4 mr-2" />
              Catat Transaksi
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Catat Transaksi Baru</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tipe Transaksi</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-type">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="in">Stok Masuk</SelectItem>
                          <SelectItem value="out">Stok Keluar</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="medicineId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Obat</FormLabel>
                        <Select
                          onValueChange={(value) => field.onChange(parseInt(value))}
                          value={field.value?.toString()}
                        >
                          <FormControl>
                            <SelectTrigger data-testid="select-medicine">
                              <SelectValue placeholder="Pilih obat" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {medicines?.map((med) => (
                              <SelectItem key={med.id} value={med.id.toString()}>
                                {med.name} ({med.code})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="quantity"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Jumlah</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            type="number"
                            onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                            data-testid="input-quantity"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {transactionType === "in" && (
                  <FormField
                    control={form.control}
                    name="supplierId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Supplier</FormLabel>
                        <Select
                          onValueChange={(value) => field.onChange(value ? parseInt(value) : undefined)}
                          value={field.value?.toString()}
                        >
                          <FormControl>
                            <SelectTrigger data-testid="select-supplier">
                              <SelectValue placeholder="Pilih supplier (opsional)" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {suppliers?.map((sup) => (
                              <SelectItem key={sup.id} value={sup.id.toString()}>
                                {sup.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                {transactionType === "out" && (
                  <FormField
                    control={form.control}
                    name="patientName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nama Pasien</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Nama pasien (opsional)" data-testid="input-patient" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Catatan</FormLabel>
                      <FormControl>
                        <Textarea {...field} placeholder="Catatan tambahan" rows={3} data-testid="input-notes" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end gap-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                    Batal
                  </Button>
                  <Button type="submit" disabled={createMutation.isPending} data-testid="button-submit-transaction">
                    {createMutation.isPending ? "Menyimpan..." : "Simpan"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex gap-2">
        <Button
          variant={typeFilter === "all" ? "default" : "outline"}
          size="sm"
          onClick={() => setTypeFilter("all")}
          data-testid="filter-all"
        >
          <Filter className="w-4 h-4 mr-2" />
          Semua
        </Button>
        <Button
          variant={typeFilter === "in" ? "default" : "outline"}
          size="sm"
          onClick={() => setTypeFilter("in")}
          data-testid="filter-in"
        >
          <ArrowDown className="w-4 h-4 mr-2" />
          Stok Masuk
        </Button>
        <Button
          variant={typeFilter === "out" ? "default" : "outline"}
          size="sm"
          onClick={() => setTypeFilter("out")}
          data-testid="filter-out"
        >
          <ArrowUp className="w-4 h-4 mr-2" />
          Stok Keluar
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
      ) : filteredTransactions && filteredTransactions.length === 0 ? (
        <Card className="p-12">
          <div className="text-center">
            <h3 className="text-lg font-semibold mb-2">Belum ada transaksi</h3>
            <p className="text-muted-foreground">
              {typeFilter !== "all" ? "Tidak ada transaksi dengan filter ini" : "Mulai catat transaksi baru"}
            </p>
          </div>
        </Card>
      ) : (
        <div className="space-y-3">
          {filteredTransactions?.map((transaction: any) => (
            <Card key={transaction.id} className="hover-elevate" data-testid={`transaction-${transaction.id}`}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-4 flex-1 min-w-0">
                    <div className={`w-10 h-10 rounded-md flex items-center justify-center ${
                      transaction.type === "in" ? "bg-chart-1/10 text-chart-1" : "bg-chart-2/10 text-chart-2"
                    }`}>
                      {transaction.type === "in" ? (
                        <ArrowDown className="w-5 h-5" />
                      ) : (
                        <ArrowUp className="w-5 h-5" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold truncate">{transaction.medicine?.name || "-"}</h3>
                        <Badge variant={transaction.type === "in" ? "default" : "secondary"}>
                          {transaction.type === "in" ? "Masuk" : "Keluar"}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>{new Date(transaction.transactionDate).toLocaleDateString('id-ID')}</span>
                        {transaction.type === "in" && transaction.supplier && (
                          <span>Supplier: {transaction.supplier.name}</span>
                        )}
                        {transaction.type === "out" && transaction.patientName && (
                          <span>Pasien: {transaction.patientName}</span>
                        )}
                      </div>
                      {transaction.notes && (
                        <p className="text-sm text-muted-foreground mt-1 truncate">
                          {transaction.notes}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-2xl font-mono font-bold ${
                      transaction.type === "in" ? "text-chart-1" : "text-chart-2"
                    }`}>
                      {transaction.type === "in" ? "+" : "-"}{transaction.quantity}
                    </p>
                    <p className="text-xs text-muted-foreground">{transaction.medicine?.unit || "pcs"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
