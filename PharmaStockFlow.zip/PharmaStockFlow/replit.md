# Pharmacy Inventory Management System

## Overview
Sistem manajemen inventory farmasi yang modern dan efisien untuk apotek. Aplikasi ini membantu mengelola stok obat, transaksi, dan laporan dengan mudah.

## Tech Stack
- **Frontend**: React + TypeScript + Tailwind CSS + Shadcn UI
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL (via Neon)
- **ORM**: Drizzle ORM
- **Authentication**: Replit Auth (supports Google, GitHub, X, Apple, Email/Password)
- **State Management**: TanStack Query (React Query)
- **Routing**: Wouter
- **Reports**: jsPDF, xlsx

## Features

### Core Features (MVP)
1. **Role-Based Authentication**
   - Admin role: Full access to all features
   - Staff role: Limited access (can view, add transactions, but cannot delete medicines)
   - Powered by Replit Auth

2. **Medicine Management (CRUD)**
   - Add, edit, view, and delete medicines
   - Medicine attributes: code, name, category, description, price, stock, minimum stock threshold, manufacturer
   - Search and filter by category
   - Grid view with status indicators (Normal, Low Stock, Out of Stock)

3. **Transaction Management**
   - Record stock IN (purchases from suppliers)
   - Record stock OUT (dispensing to patients)
   - Automatic stock updates
   - Transaction history with filters
   - Links to suppliers and patients

4. **Inventory Dashboard**
   - Real-time statistics: Total medicines, low stock count, inventory value, transactions
   - Low stock alerts with visual indicators
   - Recent transactions timeline

5. **Reports & Export**
   - Inventory Report: All medicines with stock and value
   - Transaction Report: All stock movements
   - Export to PDF and Excel formats
   - Preview before export

6. **Admin Management** (Admin only)
   - Category management
   - Supplier management
   - User role management

7. **Stock Alerts**
   - Automatic detection when stock <= minimum stock
   - Visual warnings on dashboard
   - Color-coded indicators (Green: Normal, Amber: Low, Red: Out)

## Database Schema

### Users
- id (varchar, primary key)
- email, firstName, lastName, profileImageUrl
- role (admin/staff)
- createdAt, updatedAt

### Categories
- id (serial, primary key)
- name, description
- createdAt

### Suppliers
- id (serial, primary key)
- name, contactPerson, phone, email, address
- createdAt

### Medicines
- id (serial, primary key)
- code, name, categoryId, description
- unit, price, stock, minStock
- manufacturer, expiryDate
- createdAt, updatedAt

### Transactions
- id (serial, primary key)
- type (in/out)
- medicineId, quantity, userId
- supplierId (for stock in), patientName (for stock out)
- notes, transactionDate
- createdAt

### Sessions (for auth)
- sid, sess, expire

## API Endpoints

### Authentication
- `GET /api/auth/user` - Get current user
- `GET /api/login` - Start login flow
- `GET /api/logout` - Logout

### Users (Admin only)
- `GET /api/users` - Get all users
- `PATCH /api/users/:id/role` - Update user role

### Categories
- `GET /api/categories` - Get all categories
- `POST /api/categories` - Create category (Admin)
- `PATCH /api/categories/:id` - Update category (Admin)
- `DELETE /api/categories/:id` - Delete category (Admin)

### Suppliers
- `GET /api/suppliers` - Get all suppliers
- `POST /api/suppliers` - Create supplier (Admin)
- `PATCH /api/suppliers/:id` - Update supplier (Admin)
- `DELETE /api/suppliers/:id` - Delete supplier (Admin)

### Medicines
- `GET /api/medicines` - Get all medicines
- `GET /api/medicines/low-stock` - Get low stock medicines
- `POST /api/medicines` - Create medicine
- `PATCH /api/medicines/:id` - Update medicine
- `DELETE /api/medicines/:id` - Delete medicine (Admin)

### Transactions
- `GET /api/transactions` - Get all transactions
- `POST /api/transactions` - Create transaction (auto updates stock)

## Design System
- **Primary Color**: Medical Green (142 71% 45%) - represents health and trust
- **Secondary Color**: Clinical Blue (211 100% 50%) - professionalism
- **Typography**: Inter for UI, JetBrains Mono for numbers/codes
- **Components**: Shadcn UI with medical-grade attention to detail
- **Responsive**: Mobile-first design, works on all devices
- **Dark Mode**: Full support with proper color contrast

## Key User Flows

### Admin Flow
1. Login → Dashboard (see alerts)
2. Manage Categories & Suppliers
3. Add/Edit Medicines
4. Record Transactions
5. Manage User Roles
6. Generate Reports

### Staff Flow
1. Login → Dashboard (see alerts)
2. View Medicines (search/filter)
3. Record Transactions (stock in/out)
4. Generate Reports

## Project Structure
```
/client
  /src
    /components - Reusable UI components
    /pages - Route pages (Dashboard, Medicines, etc.)
    /hooks - Custom hooks (useAuth)
    /lib - Utilities (queryClient, authUtils)
/server
  db.ts - Database connection
  routes.ts - API endpoints
  storage.ts - Data access layer
  replitAuth.ts - Authentication setup
/shared
  schema.ts - Database schema & types
```

## Development Commands
- `npm run dev` - Start development server (frontend + backend)
- `npm run db:push` - Push schema changes to database
- `npm run build` - Build for production

## Environment Variables
- `DATABASE_URL` - PostgreSQL connection string
- `SESSION_SECRET` - Session encryption secret
- `REPLIT_DOMAINS` - Allowed domains for OAuth
- `REPL_ID` - Replit app ID

## Future Enhancements
- Barcode scanner integration
- Analytics dashboard with charts
- Stock prediction based on historical data
- Multi-pharmacy/branch management
- Integration with electronic prescription systems
- Batch expiry tracking
- SMS/Email notifications for low stock
- Mobile app (React Native)

## Notes
- First user to login becomes admin automatically (can be changed later)
- All prices in Indonesian Rupiah (IDR)
- Stock movements are tracked via transactions
- Reports include all data up to generation time
- Dark mode preference saved in localStorage
