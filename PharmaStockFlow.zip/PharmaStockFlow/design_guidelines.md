# Pharmacy Inventory Management System - Design Guidelines

## Design Approach: Material Design System

**Rationale**: Medical/healthcare inventory systems require clarity, data density handling, and professional trust. Material Design provides robust patterns for data tables, dashboards, and form-heavy interfaces while maintaining visual hierarchy.

**Key Principles**:
- Medical professionalism with clean data presentation
- Clear visual hierarchy for critical stock information
- Efficient workflow for staff daily operations
- Trust-building through consistent, reliable interface

---

## Core Design Elements

### A. Color Palette

**Light Mode:**
- Primary: `142 71% 45%` (Medical Green - trust, health)
- Primary Hover: `142 71% 38%`
- Secondary: `211 100% 50%` (Clinical Blue - professionalism)
- Background: `0 0% 98%`
- Surface: `0 0% 100%`
- Border: `214 20% 91%`
- Text Primary: `222 47% 11%`
- Text Secondary: `215 16% 47%`

**Dark Mode:**
- Primary: `142 71% 45%`
- Primary Hover: `142 71% 52%`
- Secondary: `211 100% 60%`
- Background: `222 47% 11%`
- Surface: `217 33% 17%`
- Border: `217 20% 25%`
- Text Primary: `210 40% 98%`
- Text Secondary: `217 20% 70%`

**Status Colors:**
- Success/In Stock: `142 76% 36%`
- Warning/Low Stock: `38 92% 50%`
- Danger/Out of Stock: `0 84% 60%`
- Info: `211 96% 48%`

### B. Typography

**Font Stack**: 
- Primary: 'Inter' (Google Fonts) - Clean, medical-grade readability
- Monospace: 'JetBrains Mono' - For stock numbers and codes

**Hierarchy**:
- H1: 2.25rem (36px), font-semibold - Dashboard titles
- H2: 1.875rem (30px), font-semibold - Section headers
- H3: 1.5rem (24px), font-medium - Card titles
- H4: 1.25rem (20px), font-medium - Subsections
- Body: 0.875rem (14px), font-normal - General content
- Small: 0.75rem (12px), font-normal - Metadata, captions
- Numbers/Codes: Monospace, font-medium - Stock quantities, medicine codes

### C. Layout System

**Spacing Units**: Tailwind 2, 4, 6, 8, 12 (p-2, p-4, p-6, p-8, p-12, etc.)

**Grid Structure**:
- Dashboard: 12-column grid with 24px gutters
- Cards: 4px border-radius, 1px border
- Tables: Full-width with alternating row colors
- Forms: Two-column layouts on desktop, single-column mobile
- Sidebar: 256px fixed width on desktop, drawer on mobile

**Responsive Breakpoints**:
- Mobile: < 640px (single column, drawer navigation)
- Tablet: 640px - 1024px (2-column cards)
- Desktop: > 1024px (full layout with sidebar)

### D. Component Library

**Navigation**:
- Top Bar: Logo left, user profile/notifications right, 64px height
- Sidebar: Collapsible, icons + labels, role-based menu items
- Breadcrumbs: For deep navigation in medicine/transaction details

**Dashboard Cards**:
- Summary Cards: 4-column grid (Total Medicines, Low Stock, Value, Recent Activity)
- Each card: Icon, large number display, trend indicator, background subtle gradient
- Stock Status Visual: Progress bars for category-wise stock levels

**Data Tables**:
- Sticky header with sort icons
- Row actions dropdown (Edit, Delete, View History)
- Pagination: 10/25/50/100 items per page
- Quick filters: Category, Stock Status, Date Range
- Search bar with debounce, icon left-aligned
- Zebra striping for row distinction

**Forms**:
- Input fields: 40px height, 8px padding, focus ring in primary color
- Labels: Above inputs, 12px font-size, medium weight
- Required fields: Red asterisk indicator
- Dropdowns: Searchable for categories, suppliers
- Date pickers: Calendar widget for transaction dates
- Number inputs: Spinners for stock quantities
- File upload: For importing bulk medicine data

**Medicine Cards** (Grid View):
- Image placeholder (pill icon if no image)
- Medicine name (bold), category (secondary text)
- Stock quantity (large, color-coded by status)
- Price display
- Quick action buttons (Edit, Adjust Stock)

**Transaction Components**:
- Transaction history timeline with icons
- Stock In cards: Green accent, supplier info
- Stock Out cards: Blue accent, patient/purpose info
- Expandable details for full transaction data

**Alerts & Notifications**:
- Low Stock Alert: Amber background, pill icon, dismiss button
- Success Messages: Green toast, auto-dismiss 3s
- Error Messages: Red banner, manual dismiss
- Notification Bell: Badge count for unread alerts

**Reports Section**:
- Filter panel: Date range, categories, transaction type
- Preview table of report data
- Export buttons: PDF (red icon), Excel (green icon)
- Print-optimized layout for PDF generation

**Modals & Dialogs**:
- Add/Edit Medicine: Full-width form modal
- Stock Adjustment: Quick modal with quantity input
- Delete Confirmation: Small centered modal
- Backdrop: Dark overlay with blur

### E. Data Visualization

**Stock Level Indicators**:
- Linear progress bars for stock percentage
- Color-coded: Green (>50%), Amber (20-50%), Red (<20%)
- Circular badges for quick stock status

**Charts** (for dashboard):
- Stock trends: Line chart (last 30 days)
- Category distribution: Donut chart
- Top medicines: Horizontal bar chart
- Transaction volume: Area chart

Use Chart.js or Recharts library with consistent color scheme

### F. Role-Based UI Variations

**Admin View**:
- Full access to all features
- User management section
- System settings access
- Audit logs visible

**Staff View**:
- Medicine viewing/searching
- Limited stock adjustments (requires approval)
- Transaction recording
- Basic reports only
- No delete permissions

Visual distinction: Admin badge, additional menu items highlighted

---

## Mobile Optimization

**Touch Targets**: Minimum 44px for all interactive elements

**Mobile-Specific Patterns**:
- Bottom navigation bar for quick actions
- Swipe gestures for table row actions
- Floating Action Button for "Add Medicine"
- Simplified filters in slide-out drawer
- Stack cards vertically with full width
- Horizontal scroll for wide tables (with scroll hint)

**Performance**: 
- Lazy load table rows (virtual scrolling for 100+ items)
- Compress images to WebP format
- Skeleton loaders for data fetching

---

## Images

**Hero Section**: Not applicable for this dashboard application

**Icon Usage**:
- Heroicons for UI elements (outline style)
- Medicine categories: Use relevant icons (pill, syringe, capsule, bottle)
- Transaction types: Arrow icons (up for stock in, down for stock out)
- Dashboard metrics: Custom icons for each KPI

**Placeholder Images**:
- Medicine cards without images: Pill icon on gradient background
- Empty states: Friendly illustration with actionable message

---

## Accessibility & States

**Focus States**: 2px primary color ring, 4px offset
**Hover States**: Subtle background color change (5% opacity shift)
**Disabled States**: 40% opacity, not-allowed cursor
**Loading States**: Shimmer skeleton for tables, spinner for buttons

**Dark Mode**: Maintain WCAG AA contrast ratios, reduce bright colors, ensure form inputs remain clearly visible