import {
  users,
  categories,
  suppliers,
  medicines,
  transactions,
  type User,
  type UpsertUser,
  type Category,
  type InsertCategory,
  type Supplier,
  type InsertSupplier,
  type Medicine,
  type InsertMedicine,
  type Transaction,
  type InsertTransaction,
} from "@shared/schema";
import { db } from "./db";
import { eq, lte, desc } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  updateUserRole(id: string, role: string): Promise<User>;

  // Category operations
  getAllCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: InsertCategory): Promise<Category>;
  deleteCategory(id: number): Promise<void>;

  // Supplier operations
  getAllSuppliers(): Promise<Supplier[]>;
  getSupplier(id: number): Promise<Supplier | undefined>;
  createSupplier(supplier: InsertSupplier): Promise<Supplier>;
  updateSupplier(id: number, supplier: InsertSupplier): Promise<Supplier>;
  deleteSupplier(id: number): Promise<void>;

  // Medicine operations
  getAllMedicines(): Promise<Medicine[]>;
  getMedicine(id: number): Promise<Medicine | undefined>;
  getLowStockMedicines(): Promise<Medicine[]>;
  createMedicine(medicine: InsertMedicine): Promise<Medicine>;
  updateMedicine(id: number, medicine: InsertMedicine): Promise<Medicine>;
  deleteMedicine(id: number): Promise<void>;
  updateStock(id: number, quantity: number, isAddition: boolean): Promise<Medicine>;

  // Transaction operations
  getAllTransactions(): Promise<any[]>;
  getTransaction(id: number): Promise<Transaction | undefined>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async updateUserRole(id: string, role: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ role, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Category operations
  async getAllCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  async getCategory(id: number): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.id, id));
    return category;
  }

  async createCategory(categoryData: InsertCategory): Promise<Category> {
    const [category] = await db.insert(categories).values(categoryData).returning();
    return category;
  }

  async updateCategory(id: number, categoryData: InsertCategory): Promise<Category> {
    const [category] = await db
      .update(categories)
      .set(categoryData)
      .where(eq(categories.id, id))
      .returning();
    return category;
  }

  async deleteCategory(id: number): Promise<void> {
    await db.delete(categories).where(eq(categories.id, id));
  }

  // Supplier operations
  async getAllSuppliers(): Promise<Supplier[]> {
    return await db.select().from(suppliers);
  }

  async getSupplier(id: number): Promise<Supplier | undefined> {
    const [supplier] = await db.select().from(suppliers).where(eq(suppliers.id, id));
    return supplier;
  }

  async createSupplier(supplierData: InsertSupplier): Promise<Supplier> {
    const [supplier] = await db.insert(suppliers).values(supplierData).returning();
    return supplier;
  }

  async updateSupplier(id: number, supplierData: InsertSupplier): Promise<Supplier> {
    const [supplier] = await db
      .update(suppliers)
      .set(supplierData)
      .where(eq(suppliers.id, id))
      .returning();
    return supplier;
  }

  async deleteSupplier(id: number): Promise<void> {
    await db.delete(suppliers).where(eq(suppliers.id, id));
  }

  // Medicine operations
  async getAllMedicines(): Promise<Medicine[]> {
    return await db.select().from(medicines);
  }

  async getMedicine(id: number): Promise<Medicine | undefined> {
    const [medicine] = await db.select().from(medicines).where(eq(medicines.id, id));
    return medicine;
  }

  async getLowStockMedicines(): Promise<Medicine[]> {
    return await db
      .select()
      .from(medicines)
      .where(lte(medicines.stock, medicines.minStock));
  }

  async createMedicine(medicineData: InsertMedicine): Promise<Medicine> {
    const [medicine] = await db.insert(medicines).values(medicineData).returning();
    return medicine;
  }

  async updateMedicine(id: number, medicineData: InsertMedicine): Promise<Medicine> {
    const [medicine] = await db
      .update(medicines)
      .set({ ...medicineData, updatedAt: new Date() })
      .where(eq(medicines.id, id))
      .returning();
    return medicine;
  }

  async deleteMedicine(id: number): Promise<void> {
    await db.delete(medicines).where(eq(medicines.id, id));
  }

  async updateStock(id: number, quantity: number, isAddition: boolean): Promise<Medicine> {
    const medicine = await this.getMedicine(id);
    if (!medicine) {
      throw new Error("Medicine not found");
    }

    const newStock = isAddition ? medicine.stock + quantity : medicine.stock - quantity;
    
    if (newStock < 0) {
      throw new Error("Insufficient stock");
    }

    const [updated] = await db
      .update(medicines)
      .set({ stock: newStock, updatedAt: new Date() })
      .where(eq(medicines.id, id))
      .returning();
    
    return updated;
  }

  // Transaction operations
  async getAllTransactions(): Promise<any[]> {
    const txns = await db.query.transactions.findMany({
      with: {
        medicine: true,
        user: true,
        supplier: true,
      },
      orderBy: [desc(transactions.transactionDate)],
    });
    return txns;
  }

  async getTransaction(id: number): Promise<Transaction | undefined> {
    const [transaction] = await db.select().from(transactions).where(eq(transactions.id, id));
    return transaction;
  }

  async createTransaction(transactionData: InsertTransaction): Promise<Transaction> {
    // Use transaction to ensure atomicity
    return await db.transaction(async (tx) => {
      // Create transaction record
      const [transaction] = await tx.insert(transactions).values(transactionData).returning();
      
      // Update medicine stock
      const medicine = await tx.query.medicines.findFirst({
        where: eq(medicines.id, transactionData.medicineId),
      });

      if (!medicine) {
        throw new Error("Medicine not found");
      }

      const newStock = transactionData.type === "in" 
        ? medicine.stock + transactionData.quantity 
        : medicine.stock - transactionData.quantity;

      if (newStock < 0) {
        throw new Error("Insufficient stock");
      }

      await tx
        .update(medicines)
        .set({ stock: newStock, updatedAt: new Date() })
        .where(eq(medicines.id, transactionData.medicineId));
      
      return transaction;
    });
  }
}

export const storage = new DatabaseStorage();
