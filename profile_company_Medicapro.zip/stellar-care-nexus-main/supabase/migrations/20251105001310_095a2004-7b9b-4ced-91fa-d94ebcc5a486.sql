-- Fix function search path security issue
-- Drop trigger first
DROP TRIGGER IF EXISTS update_job_applications_updated_at ON public.job_applications;

-- Drop function
DROP FUNCTION IF EXISTS public.update_job_applications_updated_at();

-- Recreate function with proper search_path
CREATE OR REPLACE FUNCTION public.update_job_applications_updated_at()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Recreate trigger
CREATE TRIGGER update_job_applications_updated_at
BEFORE UPDATE ON public.job_applications
FOR EACH ROW
EXECUTE FUNCTION public.update_job_applications_updated_at();