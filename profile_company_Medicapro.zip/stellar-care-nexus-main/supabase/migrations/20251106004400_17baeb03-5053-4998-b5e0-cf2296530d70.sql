-- Create storage bucket for job application documents
INSERT INTO storage.buckets (id, name, public) 
VALUES ('job-applications', 'job-applications', true);

-- Create policy to allow anyone to upload job application documents
CREATE POLICY "Anyone can upload job application documents"
ON storage.objects
FOR INSERT
TO public
WITH CHECK (bucket_id = 'job-applications');

-- Create policy to allow public access to view job application documents
CREATE POLICY "Public can view job application documents"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'job-applications');