import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import LoadingBar from "@/components/LoadingBar";
import Index from "./pages/Index";
import Informasi from "./pages/Informasi";
import Fasilitas from "./pages/Fasilitas";
import TentangKami from "./pages/TentangKami";
import Pendaftaran from "./pages/Pendaftaran";
import Spesialisasi from "./pages/Spesialisasi";
import Dokter from "./pages/Dokter";
import Karir from "./pages/Karir";
import LamaranKerja from "./pages/LamaranKerja";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <LoadingBar />
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/informasi" element={<Informasi />} />
          <Route path="/fasilitas" element={<Fasilitas />} />
          <Route path="/tentang-kami" element={<TentangKami />} />
          <Route path="/pendaftaran" element={<Pendaftaran />} />
          <Route path="/spesialisasi" element={<Spesialisasi />} />
          <Route path="/dokter" element={<Dokter />} />
          <Route path="/karir" element={<Karir />} />
          <Route path="/lamaran-kerja" element={<LamaranKerja />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
