import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import heroImage from "@/assets/hero-hospital.jpg";
import { ArrowRight, Phone } from "lucide-react";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden pt-16">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0">
        <img 
          src={heroImage} 
          alt="Fasilitas rumah sakit modern dengan taman penyembuhan" 
          className="w-full h-full object-cover brightness-75"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-foreground/70 via-foreground/60 to-foreground/70" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="max-w-4xl">
          <div className="inline-block mb-6 px-4 py-2 bg-card/10 backdrop-blur-sm rounded-full border border-primary-foreground/20">
            <span className="text-primary-foreground font-semibold">Institusi Kesehatan Terkemuka Dunia</span>
          </div>
          
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-primary-foreground mb-6 leading-tight">
            Keunggulan dalam
            <span className="block bg-gradient-to-r from-secondary to-accent bg-clip-text text-transparent">
              Inovasi Kesehatan
            </span>
          </h1>
          
          <p className="text-lg sm:text-xl md:text-2xl text-primary-foreground/90 mb-8 sm:mb-10 max-w-2xl leading-relaxed">
            Memberikan perawatan medis kelas dunia dengan kasih sayang, teknologi terkini, dan keahlian tak tertandingi di lebih dari 150 spesialisasi.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" variant="secondary" className="text-lg" asChild>
              <Link to="/pendaftaran">
                Pendaftaran
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="text-lg border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10">
              <Phone className="mr-2 h-5 w-5" />
              Darurat: +1 (555) 911-0000
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-12 sm:mt-16 pt-8 sm:pt-12 border-t border-primary-foreground/20">
            {[
              { value: "50+", label: "Tahun Keunggulan" },
              { value: "150+", label: "Spesialisasi Medis" },
              { value: "2000+", label: "Profesional Kesehatan" },
              { value: "98%", label: "Kepuasan Pasien" },
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-secondary mb-2">{stat.value}</div>
                <div className="text-sm text-primary-foreground/80">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-primary-foreground/30 rounded-full flex items-start justify-center p-2">
          <div className="w-1.5 h-1.5 bg-secondary rounded-full animate-pulse" />
        </div>
      </div>
    </section>
  );
};

export default Hero;
