import medicalTeam from "@/assets/medical-team.jpg";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

const Team = () => {
  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="relative rounded-2xl overflow-hidden shadow-[var(--shadow-lg)] order-2 lg:order-1">
            <img 
              src={medicalTeam} 
              alt="Tim medis profesional kesehatan yang beragam" 
              className="w-full h-full object-cover"
            />
          </div>

          <div className="order-1 lg:order-2">
            <div className="inline-block px-4 py-2 bg-primary/10 rounded-full mb-4">
              <span className="text-primary font-semibold">Tim Medis Kami</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-6">
              Terkenal di Dunia
              <span className="block text-primary mt-2">Ahli Kesehatan</span>
            </h2>
            <p className="text-lg text-muted-foreground mb-6">
              Tim kami terdiri dari lebih dari 2.000 dokter bersertifikat, ahli bedah, dan profesional kesehatan 
              yang merupakan pemimpin di bidangnya. Banyak yang telah dilatih di institusi medis terbaik dunia dan 
              berkontribusi pada penelitian terobosan di spesialisasi mereka.
            </p>
            
            <div className="space-y-4 mb-8">
              {[
                "Spesialis bersertifikat di 150+ bidang medis",
                "Dokter dan ahli bedah pemenang penghargaan penelitian",
                "Staf multibahasa melayani pasien internasional",
                "Koordinator perawatan pasien yang berdedikasi",
              ].map((item, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <div className="w-2 h-2 rounded-full bg-primary" />
                  </div>
                  <p className="text-foreground">{item}</p>
                </div>
              ))}
            </div>

            <Button size="lg" variant="default" asChild>
              <Link to="/dokter">
                Temui Dokter Kami
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Team;
