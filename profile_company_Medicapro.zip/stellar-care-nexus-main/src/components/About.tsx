import { Card } from "@/components/ui/card";
import { Heart, Award, Users, Globe } from "lucide-react";

const About = () => {
  const values = [
    {
      icon: Heart,
      title: "Perawatan Berpusat pada Pasien",
      description: "Setiap keputusan yang kami buat mengutamakan kesehatan, kenyamanan, dan kesejahteraan Anda dengan rencana perawatan yang dipersonalisasi.",
    },
    {
      icon: Award,
      title: "Keunggulan Medis",
      description: "Diakui secara global untuk perawatan perintis dan secara konsisten menempati peringkat #1 dalam berbagai spesialisasi.",
    },
    {
      icon: Users,
      title: "Tim Ahli",
      description: "Lebih dari 2.000 dokter bersertifikat, ahli bedah, dan profesional kesehatan dari seluruh dunia.",
    },
    {
      icon: Globe,
      title: "Dampak Global",
      description: "Melayani pasien dari 140+ negara dengan fasilitas canggih di berbagai benua.",
    },
  ];

  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 bg-primary/10 rounded-full mb-4">
            <span className="text-primary font-semibold">Tentang Kami</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-6">
            Memimpin Inovasi Kesehatan
            <span className="block text-primary mt-2">Sejak 1973</span>
          </h2>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-3xl mx-auto">
            Kami adalah institusi medis terkenal di dunia yang berkomitmen untuk memberikan perawatan pasien yang luar biasa, 
            memajukan penelitian medis, dan mendidik generasi pemimpin kesehatan berikutnya.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {values.map((value, index) => (
            <Card 
              key={index} 
              className="p-8 hover:shadow-[var(--shadow-lg)] transition-all duration-300 hover:-translate-y-1 border-border bg-card"
            >
              <div className="w-14 h-14 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mb-6">
                <value.icon className="h-7 w-7 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-bold text-card-foreground mb-3">{value.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{value.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;
