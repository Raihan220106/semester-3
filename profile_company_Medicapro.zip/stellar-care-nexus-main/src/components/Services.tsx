import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import medicalTechnology from "@/assets/medical-technology.jpg";
import { 
  Activity, 
  Brain, 
  Heart, 
  Stethoscope, 
  Microscope, 
  Baby,
  ArrowRight
} from "lucide-react";

const Services = () => {
  const services = [
    {
      icon: Heart,
      title: "Kardiologi & Bedah Jantung",
      description: "Perawatan jantung komprehensif termasuk prosedur intervensi canggih dan transplantasi.",
      featured: true,
    },
    {
      icon: Brain,
      title: "Neurologi & Bedah Saraf",
      description: "Perawatan otak dan tulang belakang terkemuka di dunia dengan teknik invasif minimal.",
      featured: true,
    },
    {
      icon: Activity,
      title: "Onkologi & Perawatan Kanker",
      description: "Perawatan kanker terkini dengan terapi personal dan uji klinis.",
      featured: true,
    },
    {
      icon: Stethoscope,
      title: "Penyakit Dalam",
      description: "Diagnosis ahli dan perawatan kondisi medis kompleks.",
      featured: false,
    },
    {
      icon: Microscope,
      title: "Patologi & Laboratorium",
      description: "Layanan diagnostik canggih dengan ketersediaan 24/7.",
      featured: false,
    },
    {
      icon: Baby,
      title: "Pediatri & Neonatologi",
      description: "Perawatan khusus untuk bayi, anak-anak, dan remaja.",
      featured: false,
    },
  ];

  return (
    <section className="py-24 bg-muted/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <div className="inline-block px-4 py-2 bg-primary/10 rounded-full mb-4">
              <span className="text-primary font-semibold">Layanan Kami</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-6">
              Keunggulan Medis Komprehensif
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Dengan lebih dari 150 departemen dan layanan khusus, kami menyediakan perawatan terintegrasi 
              dan multidisiplin yang menangani setiap aspek perjalanan kesehatan Anda.
            </p>
            <Button size="lg" variant="default" asChild>
              <Link to="/spesialisasi">
                Lihat Semua Spesialisasi
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>

          <div className="relative rounded-2xl overflow-hidden shadow-[var(--shadow-lg)]">
            <img 
              src={medicalTechnology} 
              alt="Teknologi dan peralatan medis canggih" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <Card 
              key={index}
              className={`p-8 hover:shadow-[var(--shadow-lg)] transition-all duration-300 hover:-translate-y-1 ${
                service.featured ? 'border-primary/30 bg-gradient-to-br from-card to-primary/5' : 'bg-card'
              }`}
            >
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 ${
                service.featured 
                  ? 'bg-gradient-to-br from-primary to-secondary' 
                  : 'bg-muted'
              }`}>
                <service.icon className={`h-7 w-7 ${
                  service.featured ? 'text-primary-foreground' : 'text-primary'
                }`} />
              </div>
              <h3 className="text-xl font-bold text-card-foreground mb-3">{service.title}</h3>
              <p className="text-muted-foreground mb-4">{service.description}</p>
              <Button variant="link" className="p-0 h-auto text-primary">
                Pelajari Lebih Lanjut <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
