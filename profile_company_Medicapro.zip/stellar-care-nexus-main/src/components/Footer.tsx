import { Heart, Facebook, Instagram, Twitter, Linkedin, Youtube, MapPin } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-foreground text-background py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div className="sm:col-span-2 lg:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Heart className="h-8 w-8 text-secondary fill-secondary" />
              <span className="text-2xl font-bold">Medica Pro</span>
            </div>
            <p className="text-background/80 mb-4">
              Memimpin keunggulan dalam pelayanan kesehatan, inovasi, dan perawatan pasien yang penuh kasih sejak 1973.
            </p>
            <div className="flex gap-4">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-background/80 hover:text-secondary transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-background/80 hover:text-secondary transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-background/80 hover:text-secondary transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-background/80 hover:text-secondary transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="text-background/80 hover:text-secondary transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-bold mb-4">Tautan Cepat</h4>
            <ul className="space-y-2 text-background/80">
              <li><a href="/tentang-kami" className="hover:text-secondary transition-colors">Tentang Kami</a></li>
              <li><a href="/fasilitas" className="hover:text-secondary transition-colors">Layanan Kami</a></li>
              <li><a href="/dokter" className="hover:text-secondary transition-colors">Cari Dokter</a></li>
              <li><a href="/informasi" className="hover:text-secondary transition-colors">Sumber Daya Pasien</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4">Dukungan</h4>
            <ul className="space-y-2 text-background/80">
              <li><a href="/#contact" className="hover:text-secondary transition-colors">Hubungi Kami</a></li>
              <li><a href="/karir" className="hover:text-secondary transition-colors">Karir</a></li>
              <li><a href="/informasi" className="hover:text-secondary transition-colors">Kebijakan Privasi</a></li>
              <li><a href="/informasi" className="hover:text-secondary transition-colors">Ketentuan Layanan</a></li>
            </ul>
          </div>
        </div>

        {/* Google Maps */}
        <div className="mb-8">
          <h4 className="font-bold mb-4 text-center">Lokasi Kami</h4>
          <div className="rounded-lg overflow-hidden shadow-[var(--shadow-lg)]">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.071489524638!2d106.84081287499656!3d-6.249874693749808!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f3979816d839%3A0xd5c3ddb5c85449da!2sSoepomo%20Office%20Park!5e0!3m2!1sen!2sid!4v1709123456789!5m2!1sen!2sid"
              width="100%"
              height="300"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Lokasi Medica Pro - Soepomo Office Park"
            />
          </div>
          <div className="text-center mt-4">
            <a
              href="https://maps.app.goo.gl/yhhYT4rafeozcT176"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-secondary hover:bg-secondary/90 text-primary-foreground px-6 py-3 rounded-lg font-semibold shadow-lg transition-all hover:shadow-xl hover:-translate-y-0.5"
            >
              <MapPin className="h-5 w-5" />
              Buka di Google Maps untuk Navigasi
            </a>
          </div>
          <p className="text-center text-background/80 mt-4">
            Soepomo Office Park, Jl. Prof. DR. Soepomo SH No.143 Blok A,B,C, RT.13/RW.2, Tebet Bar., Kec. Tebet, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12810
          </p>
        </div>

        <div className="pt-8 border-t border-background/20 text-center text-background/60">
          <p>&copy; {new Date().getFullYear()} Medica Pro. Seluruh hak cipta dilindungi.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
