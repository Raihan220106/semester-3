import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { Phone, Mail, MapPin, Clock } from "lucide-react";

const Contact = () => {
  const contactInfo = [
    {
      icon: Phone,
      title: "Darurat",
      content: "+1 (555) 911-0000",
      subContent: "Perawatan Darurat 24/7",
    },
    {
      icon: Phone,
      title: "Janji Temu",
      content: "+1 (555) 123-4567",
      subContent: "Sen-Jum: 8 Pagi - 6 Sore",
    },
    {
      icon: Mail,
      title: "Email",
      content: "info@globalhospital.com",
      subContent: "Respon dalam 24 jam",
    },
    {
      icon: MapPin,
      title: "Lokasi",
      content: "Soepomo Office Park",
      subContent: "Jakarta Selatan, DKI Jakarta",
    },
  ];

  return (
    <section className="py-24 bg-gradient-to-br from-primary via-primary to-secondary relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, white 1px, transparent 0)`,
          backgroundSize: '40px 40px'
        }} />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 bg-primary-foreground/10 backdrop-blur-sm rounded-full mb-4">
            <span className="text-primary-foreground font-semibold">Hubungi Kami</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-primary-foreground mb-6">
            Kami Siap Membantu Anda
          </h2>
          <p className="text-lg sm:text-xl text-primary-foreground/90 max-w-2xl mx-auto">
            Tim kami yang berdedikasi tersedia 24/7 untuk membantu Anda dengan janji temu, 
            keadaan darurat, dan kebutuhan kesehatan lainnya.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {contactInfo.map((info, index) => (
            <Card 
              key={index}
              className="p-6 bg-card/95 backdrop-blur-sm hover:bg-card transition-all duration-300 hover:-translate-y-1 hover:shadow-[var(--shadow-glow)]"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center mb-4">
                <info.icon className="h-6 w-6 text-primary-foreground" />
              </div>
              <h3 className="text-lg font-bold text-card-foreground mb-2">{info.title}</h3>
              <p className="text-foreground font-semibold mb-1">{info.content}</p>
              <p className="text-sm text-muted-foreground">{info.subContent}</p>
            </Card>
          ))}
        </div>

        <Card className="p-8 md:p-12 bg-card/95 backdrop-blur-sm max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <Clock className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-card-foreground mb-2">Pendaftaran</h3>
            <p className="text-muted-foreground">
              Daftar konsultasi Anda dengan spesialis kami atau kunjungi departemen darurat kami kapan saja.
            </p>
          </div>

          <div className="flex justify-center">
            <Button size="lg" variant="default" className="text-lg" asChild>
              <Link to="/pendaftaran">Pendaftaran Online</Link>
            </Button>
          </div>
        </Card>
      </div>
    </section>
  );
};

export default Contact;
