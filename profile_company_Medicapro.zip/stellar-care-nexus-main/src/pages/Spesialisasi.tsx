import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Heart, Brain, Bone, Baby, Eye, Ear, Stethoscope, Activity,
  Microscope, Users, HeartPulse, Syringe, Pill, Scan, Zap, Wind
} from "lucide-react";

const Spesialisasi = () => {
  const specializations = [
    {
      icon: Heart,
      title: "Kardiologi",
      description: "Perawatan jantung dan pembuluh darah komprehensif",
      services: ["Ekokardiografi", "Kateterisasi Jantung", "Operasi Jantung"]
    },
    {
      icon: Brain,
      title: "Neurologi",
      description: "Diagnosis dan pengobatan gangguan sistem saraf",
      services: ["MRI Otak", "EEG", "Terapi Stroke"]
    },
    {
      icon: Bone,
      title: "Ortopedi",
      description: "Perawatan tulang, sendi, dan cedera muskuloskeletal",
      services: ["Artroskopi", "Penggantian Sendi", "Operasi Tulang Belakang"]
    },
    {
      icon: Baby,
      title: "Pediatri",
      description: "Perawatan kesehatan komprehensif untuk anak-anak",
      services: ["Imunisasi", "Pemeriksaan Tumbuh Kembang", "Perawatan NICU"]
    },
    {
      icon: Eye,
      title: "Oftalmologi",
      description: "Perawatan mata dan bedah penglihatan canggih",
      services: ["LASIK", "Operasi Katarak", "Perawatan Retina"]
    },
    {
      icon: Ear,
      title: "THT",
      description: "Telinga, Hidung, dan Tenggorokan",
      services: ["Audiometri", "Endoskopi", "Bedah Sinus"]
    },
    {
      icon: Activity,
      title: "Onkologi",
      description: "Perawatan kanker komprehensif dan terapi",
      services: ["Kemoterapi", "Radioterapi", "Imunoterapi"]
    },
    {
      icon: HeartPulse,
      title: "Gastroenterologi",
      description: "Perawatan sistem pencernaan",
      services: ["Endoskopi", "Kolonoskopi", "Terapi Hati"]
    },
    {
      icon: Users,
      title: "Obstetri & Ginekologi",
      description: "Kesehatan wanita dan perawatan kehamilan",
      services: ["USG 4D", "Persalinan", "Operasi Caesar"]
    },
    {
      icon: Microscope,
      title: "Patologi",
      description: "Layanan diagnostik laboratorium",
      services: ["Biopsi", "Tes Darah", "Analisis Jaringan"]
    },
    {
      icon: Syringe,
      title: "Anestesiologi",
      description: "Manajemen nyeri dan anestesi bedah",
      services: ["Anestesi Umum", "Epidural", "Terapi Nyeri"]
    },
    {
      icon: Pill,
      title: "Farmakologi",
      description: "Layanan farmasi dan konsultasi obat",
      services: ["Konsultasi Obat", "Manajemen Obat", "Apotik 24 Jam"]
    },
    {
      icon: Scan,
      title: "Radiologi",
      description: "Pencitraan medis dan diagnostik",
      services: ["CT Scan", "MRI", "X-Ray Digital"]
    },
    {
      icon: Zap,
      title: "Urologi",
      description: "Perawatan sistem kemih dan reproduksi pria",
      services: ["Litotripsi", "Endourologi", "Bedah Prostat"]
    },
    {
      icon: Wind,
      title: "Pulmonologi",
      description: "Perawatan paru-paru dan sistem pernapasan",
      services: ["Spirometri", "Bronkoskopi", "Terapi Asma"]
    },
    {
      icon: Stethoscope,
      title: "Penyakit Dalam",
      description: "Diagnosis dan pengobatan penyakit dewasa",
      services: ["Check-up Umum", "Manajemen Diabetes", "Hipertensi"]
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-grow pt-16">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-primary via-primary/90 to-secondary py-16 sm:py-20 md:py-24">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl">
              <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-primary-foreground mb-6">
                Spesialisasi Medis
              </h1>
              <p className="text-lg sm:text-xl text-primary-foreground/90">
                Jelajahi lebih dari 150 spesialisasi medis kami dengan dokter ahli dan teknologi terkini 
                untuk memberikan perawatan terbaik bagi Anda dan keluarga.
              </p>
            </div>
          </div>
        </section>

        {/* Specializations Grid */}
        <section className="py-16 sm:py-20 md:py-24">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {specializations.map((spec, index) => {
                const Icon = spec.icon;
                return (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                        <Icon className="w-6 h-6 text-primary" />
                      </div>
                      <CardTitle className="text-xl">{spec.title}</CardTitle>
                      <CardDescription>{spec.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {spec.services.map((service, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                            <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                            <span>{service}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Spesialisasi;
