import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { Mail, Phone, Award, GraduationCap } from "lucide-react";

const Dokter = () => {
  const doctors = [
    {
      name: "Dr. Ahmad Hidayat, Sp.JP (K)",
      specialty: "Spesialis Jantung dan Pembuluh Darah",
      education: "Universitas Indonesia",
      experience: "20+ tahun",
      expertise: ["Kardiologi Intervensi", "Ekokardiografi", "Penyakit Jantung Koroner"],
      awards: ["Top Cardiologist 2023", "Excellence in Patient Care"]
    },
    {
      name: "Dr. Sarah Wijaya, Sp.S (K)",
      specialty: "Spesialis Saraf",
      education: "Universitas Gadjah Mada",
      experience: "15+ tahun",
      expertise: ["Stroke", "Epilepsi", "Gangguan Neuromuskular"],
      awards: ["Best Neurologist 2022", "Medical Innovation Award"]
    },
    {
      name: "Dr. Budi Santoso, Sp.OT (K)",
      specialty: "Spesialis Ortopedi",
      education: "Universitas Airlangga",
      experience: "18+ tahun",
      expertise: ["Bedah Tulang Belakang", "Artroskopi", "Trauma Ortopedi"],
      awards: ["Excellence in Surgery 2023"]
    },
    {
      name: "Dr. Lisa Kartini, Sp.A (K)",
      specialty: "Spesialis Anak",
      education: "Universitas Padjadjaran",
      experience: "12+ tahun",
      expertise: ["Neonatologi", "Tumbuh Kembang", "Alergi Anak"],
      awards: ["Pediatrician of the Year 2022"]
    },
    {
      name: "Dr. Michael Chen, Sp.M (K)",
      specialty: "Spesialis Mata",
      education: "National University of Singapore",
      experience: "16+ tahun",
      expertise: ["LASIK", "Bedah Katarak", "Retina"],
      awards: ["Top Ophthalmologist 2023", "Innovation in Eye Surgery"]
    },
    {
      name: "Dr. Dewi Lestari, Sp.OG (K)",
      specialty: "Spesialis Kebidanan & Kandungan",
      education: "Universitas Indonesia",
      experience: "14+ tahun",
      expertise: ["Kehamilan Risiko Tinggi", "Infertilitas", "Bedah Laparoskopi"],
      awards: ["Excellence in Women's Health 2023"]
    },
    {
      name: "Dr. Rahmat Hidayat, Sp.PD-KHOM",
      specialty: "Spesialis Penyakit Dalam - Onkologi",
      education: "Universitas Diponegoro",
      experience: "17+ tahun",
      expertise: ["Kemoterapi", "Imunoterapi", "Kanker Paru"],
      awards: ["Outstanding Oncologist 2022"]
    },
    {
      name: "Dr. Rina Kusuma, Sp.THT-KL (K)",
      specialty: "Spesialis THT",
      education: "Universitas Hasanuddin",
      experience: "13+ tahun",
      expertise: ["Bedah Endoskopi Sinus", "Implant Koklea", "Gangguan Pendengaran"],
      awards: ["Excellence in ENT Surgery 2023"]
    },
    {
      name: "Dr. David Prasetyo, Sp.U (K)",
      specialty: "Spesialis Urologi",
      education: "Universitas Indonesia",
      experience: "15+ tahun",
      expertise: ["Bedah Minimal Invasif", "Litotripsi", "Kanker Prostat"],
      awards: ["Top Urologist 2022"]
    },
    {
      name: "Dr. Maya Sari, Sp.BP-RE (K)",
      specialty: "Spesialis Bedah Plastik",
      education: "Universitas Airlangga",
      experience: "11+ tahun",
      expertise: ["Rekonstruksi", "Bedah Estetik", "Luka Bakar"],
      awards: ["Excellence in Aesthetic Surgery 2023"]
    },
    {
      name: "Dr. Tommy Wijaya, Sp.An (K)",
      specialty: "Spesialis Anestesi",
      education: "Universitas Gadjah Mada",
      experience: "19+ tahun",
      expertise: ["Anestesi Kardiak", "Manajemen Nyeri", "ICU"],
      awards: ["Outstanding Anesthesiologist 2022"]
    },
    {
      name: "Dr. Siti Nurhaliza, Sp.Rad (K)",
      specialty: "Spesialis Radiologi",
      education: "Universitas Indonesia",
      experience: "14+ tahun",
      expertise: ["MRI", "CT Scan", "Intervensi Radiologi"],
      awards: ["Excellence in Diagnostic Imaging 2023"]
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-grow pt-16">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-primary via-primary/90 to-secondary py-16 sm:py-20 md:py-24">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl">
              <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-primary-foreground mb-6">
                Tim Dokter Ahli Kami
              </h1>
              <p className="text-lg sm:text-xl text-primary-foreground/90 mb-8">
                Bertemulah dengan dokter-dokter berpengalaman dan tersertifikasi kami yang berdedikasi 
                memberikan perawatan medis terbaik dengan pendekatan yang komprehensif dan penuh kasih sayang.
              </p>
              <Button size="lg" variant="secondary" asChild>
                <Link to="/pendaftaran">Buat Janji dengan Dokter</Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Doctors Grid */}
        <section className="py-16 sm:py-20 md:py-24">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {doctors.map((doctor, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center mb-4 text-primary-foreground font-bold text-2xl">
                      {doctor.name.split(' ')[1][0]}{doctor.name.split(' ')[2]?.[0] || doctor.name.split(' ')[1][1]}
                    </div>
                    <CardTitle className="text-xl">{doctor.name}</CardTitle>
                    <CardDescription className="text-base font-semibold text-primary">
                      {doctor.specialty}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-start gap-2 text-sm">
                        <GraduationCap className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                        <span className="text-muted-foreground">{doctor.education}</span>
                      </div>
                      <div className="flex items-start gap-2 text-sm">
                        <Award className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                        <span className="text-muted-foreground">Pengalaman: {doctor.experience}</span>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-semibold mb-2">Keahlian:</p>
                      <div className="flex flex-wrap gap-2">
                        {doctor.expertise.map((skill, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-semibold mb-2">Penghargaan:</p>
                      <ul className="space-y-1">
                        {doctor.awards.map((award, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-xs text-muted-foreground">
                            <div className="w-1.5 h-1.5 rounded-full bg-accent mt-1.5 flex-shrink-0" />
                            <span>{award}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <Button size="sm" variant="outline" className="flex-1" asChild>
                        <Link to="/pendaftaran">
                          <Phone className="w-3 h-3 mr-1" />
                          Janji Temu
                        </Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Dokter;
