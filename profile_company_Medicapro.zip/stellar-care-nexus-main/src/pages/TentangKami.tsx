import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Card } from "@/components/ui/card";
import medicalTeam from "@/assets/medical-team.jpg";
import medicalTechnology from "@/assets/medical-technology.jpg";
import { Award, Target, Eye, Heart, Users, Globe, TrendingUp, Shield } from "lucide-react";

const TentangKami = () => {
  const values = [
    {
      icon: Heart,
      title: "Kepedulian",
      description: "Kami mengutamakan kesehatan dan kenyamanan setiap pasien dengan pelayanan penuh kasih sayang."
    },
    {
      icon: Award,
      title: "Keunggulan",
      description: "Berkomitmen memberikan standar tertinggi dalam pelayanan medis dan perawatan pasien."
    },
    {
      icon: Users,
      title: "Kolaborasi",
      description: "Tim multidisiplin bekerja sama untuk memberikan solusi kesehatan terbaik."
    },
    {
      icon: Shield,
      title: "Integritas",
      description: "Menjalankan praktik medis dengan etika profesional dan transparansi penuh."
    }
  ];

  const achievements = [
    { icon: Globe, number: "140+", label: "Negara Dilayani" },
    { icon: Award, number: "#1", label: "Rumah Sakit Terbaik" },
    { icon: Users, number: "2000+", label: "Tenaga Medis" },
    { icon: TrendingUp, number: "500K+", label: "Pasien per Tahun" }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-primary/10 via-background to-secondary/10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6">
              Tentang Kami
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground leading-relaxed">
              Medica Pro adalah institusi medis terkemuka yang telah melayani jutaan pasien 
              dari seluruh dunia dengan dedikasi terhadap keunggulan medis dan inovasi kesehatan.
            </p>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-block px-4 py-2 bg-primary/10 rounded-full mb-4">
                <span className="text-primary font-semibold">Sejarah Kami</span>
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
                50+ Tahun Melayani dengan Dedikasi
              </h2>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  Didirikan pada tahun 1973, Medica Pro dimulai dengan visi sederhana: 
                  memberikan perawatan kesehatan berkualitas tinggi yang dapat diakses oleh semua orang.
                </p>
                <p>
                  Selama lima dekade, kami telah berkembang menjadi pusat medis terkemuka dunia 
                  dengan lebih dari 150 spesialisasi dan fasilitas berteknologi tinggi.
                </p>
                <p>
                  Kami bangga telah merawat lebih dari 500,000 pasien setiap tahunnya dari 140+ negara, 
                  dengan tingkat kepuasan pasien mencapai 98%.
                </p>
              </div>
            </div>
            <div className="relative rounded-2xl overflow-hidden shadow-[var(--shadow-lg)]">
              <img 
                src={medicalTeam} 
                alt="Tim medis Medica Pro" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Vision & Mission */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8 mb-16">
            <Card className="p-8 md:p-10 bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
              <Eye className="h-12 w-12 text-primary mb-6" />
              <h3 className="text-2xl font-bold text-card-foreground mb-4">Visi Kami</h3>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Menjadi institusi kesehatan terdepan di dunia yang dikenal karena inovasi medis, 
                keunggulan klinis, dan pelayanan yang berpusat pada pasien.
              </p>
            </Card>

            <Card className="p-8 md:p-10 bg-gradient-to-br from-secondary/5 to-secondary/10 border-secondary/20">
              <Target className="h-12 w-12 text-secondary mb-6" />
              <h3 className="text-2xl font-bold text-card-foreground mb-4">Misi Kami</h3>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Memberikan perawatan kesehatan berkualitas tertinggi, mendorong penelitian medis inovatif, 
                dan mendidik generasi berikutnya pemimpin kesehatan global.
              </p>
            </Card>
          </div>

          {/* Values */}
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Nilai-Nilai Kami
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Prinsip-prinsip yang memandu setiap keputusan dan tindakan kami
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <Card 
                key={index}
                className="p-6 hover:shadow-[var(--shadow-lg)] transition-all duration-300 hover:-translate-y-1"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center mb-4">
                  <value.icon className="h-6 w-6 text-primary-foreground" />
                </div>
                <h4 className="text-lg font-bold text-card-foreground mb-2">{value.title}</h4>
                <p className="text-sm text-muted-foreground">{value.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Pencapaian Kami
            </h2>
            <p className="text-lg text-muted-foreground">
              Angka-angka yang mencerminkan dedikasi kami terhadap keunggulan
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {achievements.map((achievement, index) => (
              <Card 
                key={index}
                className="p-8 text-center hover:shadow-[var(--shadow-lg)] transition-all duration-300 hover:-translate-y-1"
              >
                <achievement.icon className="h-10 w-10 text-primary mx-auto mb-4" />
                <div className="text-4xl font-bold text-primary mb-2">{achievement.number}</div>
                <div className="text-muted-foreground">{achievement.label}</div>
              </Card>
            ))}
          </div>

          <div className="relative rounded-2xl overflow-hidden shadow-[var(--shadow-lg)]">
            <img 
              src={medicalTechnology} 
              alt="Teknologi medis canggih" 
              className="w-full h-[250px] sm:h-[350px] md:h-[400px] object-cover"
            />
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default TentangKami;
