import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format } from "date-fns";
import { id } from "date-fns/locale";
import { CalendarIcon, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

const formSchema = z.object({
  nama: z
    .string()
    .trim()
    .min(2, { message: "Nama minimal 2 karakter" })
    .max(100, { message: "Nama maksimal 100 karakter" }),
  email: z
    .string()
    .trim()
    .email({ message: "Email tidak valid" })
    .max(255, { message: "Email maksimal 255 karakter" }),
  telepon: z
    .string()
    .trim()
    .min(10, { message: "Nomor telepon minimal 10 digit" })
    .max(15, { message: "Nomor telepon maksimal 15 digit" })
    .regex(/^[0-9+\-\s()]+$/, { message: "Format nomor telepon tidak valid" }),
  tanggal: z.date({
    required_error: "Tanggal harus dipilih",
  }),
  waktu: z.string().min(1, { message: "Waktu harus dipilih" }),
  layanan: z.string().min(1, { message: "Layanan harus dipilih" }),
  dokter: z.string().optional(),
  keluhan: z
    .string()
    .trim()
    .max(500, { message: "Keluhan maksimal 500 karakter" })
    .optional(),
});

type FormValues = z.infer<typeof formSchema>;

const Pendaftaran = () => {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const doctors = [
    "Dr. Ahmad Hidayat, Sp.JP (K) - Spesialis Jantung",
    "Dr. Sarah Wijaya, Sp.S (K) - Spesialis Saraf",
    "Dr. Budi Santoso, Sp.OT (K) - Spesialis Ortopedi",
    "Dr. Lisa Kartini, Sp.A (K) - Spesialis Anak",
    "Dr. Michael Chen, Sp.M (K) - Spesialis Mata",
    "Dr. Dewi Lestari, Sp.OG (K) - Spesialis Kebidanan & Kandungan",
    "Dr. Rahmat Hidayat, Sp.PD-KHOM - Spesialis Onkologi",
    "Dr. Rina Kusuma, Sp.THT-KL (K) - Spesialis THT",
    "Dr. David Prasetyo, Sp.U (K) - Spesialis Urologi",
    "Dr. Maya Sari, Sp.BP-RE (K) - Spesialis Bedah Plastik",
    "Dr. Tommy Wijaya, Sp.An (K) - Spesialis Anestesi",
    "Dr. Siti Nurhaliza, Sp.Rad (K) - Spesialis Radiologi",
  ];

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      nama: "",
      email: "",
      telepon: "",
      layanan: "",
      dokter: "",
      keluhan: "",
      waktu: "",
    },
  });

  const onSubmit = async (data: FormValues) => {
    setIsSubmitting(true);
    
    try {
      const { error } = await supabase
        .from("registrations")
        .insert({
          nama: data.nama,
          email: data.email,
          telepon: data.telepon,
          tanggal: format(data.tanggal, "yyyy-MM-dd"),
          waktu: data.waktu,
          layanan: data.layanan,
          dokter: data.dokter || null,
          keluhan: data.keluhan || null,
        });

      if (error) throw error;

      toast({
        title: "Pendaftaran Berhasil!",
        description: "Kami akan menghubungi Anda untuk konfirmasi.",
      });
      
      setIsSubmitted(true);
      form.reset();
    } catch (error) {
      console.error("Error submitting registration:", error);
      toast({
        title: "Terjadi Kesalahan",
        description: "Gagal mengirim pendaftaran. Silakan coba lagi.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-primary/10 via-primary/5 to-background py-12 sm:py-16 md:py-20">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6">
                Pendaftaran Online
              </h1>
              <p className="text-base sm:text-lg text-muted-foreground">
                Daftar sekarang untuk mendapatkan layanan kesehatan terbaik dari kami
              </p>
            </div>
          </div>
        </section>

        {/* Form Section */}
        <section className="py-12 sm:py-16 md:py-20">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto">
              {isSubmitted ? (
                <div className="text-center py-8 sm:py-12">
                  <CheckCircle2 className="w-16 h-16 sm:w-20 sm:h-20 text-primary mx-auto mb-4 sm:mb-6" />
                  <h2 className="text-2xl sm:text-3xl font-bold mb-3 sm:mb-4">
                    Pendaftaran Berhasil!
                  </h2>
                  <p className="text-muted-foreground mb-6 sm:mb-8 text-sm sm:text-base">
                    Terima kasih telah mendaftar. Tim kami akan segera menghubungi Anda
                    untuk konfirmasi jadwal.
                  </p>
                  <Button onClick={() => setIsSubmitted(false)}>
                    Daftar Lagi
                  </Button>
                </div>
              ) : (
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="nama"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nama Lengkap *</FormLabel>
                          <FormControl>
                            <Input placeholder="Masukkan nama lengkap" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email *</FormLabel>
                            <FormControl>
                              <Input
                                type="email"
                                placeholder="email@example.com"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="telepon"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nomor Telepon *</FormLabel>
                            <FormControl>
                              <Input placeholder="08123456789" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="tanggal"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Tanggal *</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant="outline"
                                    className={cn(
                                      "w-full pl-3 text-left font-normal",
                                      !field.value && "text-muted-foreground"
                                    )}
                                  >
                                    {field.value ? (
                                      format(field.value, "PPP", { locale: id })
                                    ) : (
                                      <span>Pilih tanggal</span>
                                    )}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  disabled={(date) =>
                                    date < new Date() || date < new Date("1900-01-01")
                                  }
                                  initialFocus
                                  locale={id}
                                />
                              </PopoverContent>
                            </Popover>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="waktu"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Waktu *</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Pilih waktu" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="08:00">08:00</SelectItem>
                                <SelectItem value="09:00">09:00</SelectItem>
                                <SelectItem value="10:00">10:00</SelectItem>
                                <SelectItem value="11:00">11:00</SelectItem>
                                <SelectItem value="13:00">13:00</SelectItem>
                                <SelectItem value="14:00">14:00</SelectItem>
                                <SelectItem value="15:00">15:00</SelectItem>
                                <SelectItem value="16:00">16:00</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="layanan"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Layanan yang Dibutuhkan *</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Pilih layanan" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="umum">Pemeriksaan Umum</SelectItem>
                              <SelectItem value="gigi">Kesehatan Gigi</SelectItem>
                              <SelectItem value="anak">Kesehatan Anak</SelectItem>
                              <SelectItem value="kandungan">Kesehatan Ibu & Anak</SelectItem>
                              <SelectItem value="lab">Laboratorium</SelectItem>
                              <SelectItem value="radiologi">Radiologi</SelectItem>
                              <SelectItem value="igd">IGD</SelectItem>
                              <SelectItem value="rawat-inap">Rawat Inap</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="dokter"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Pilih Dokter (Opsional)</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Pilih dokter" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {doctors.map((doctor, index) => (
                                <SelectItem key={index} value={doctor}>
                                  {doctor}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="keluhan"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Keluhan (Opsional)</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Jelaskan keluhan Anda"
                              className="min-h-[100px]"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button type="submit" className="w-full" size="lg" disabled={isSubmitting}>
                      {isSubmitting ? "Mengirim..." : "Kirim Pendaftaran"}
                    </Button>
                  </form>
                </Form>
              )}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Pendaftaran;
