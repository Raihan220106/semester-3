import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { z } from "zod";

// Validation schema
const applicationSchema = z.object({
  fullName: z.string().trim().min(1, "Nama lengkap harus diisi").max(100),
  email: z.string().trim().email("Email tidak valid").max(255),
  phone: z.string().trim().min(10, "Nomor telepon minimal 10 digit").max(15),
  position: z.string().min(1, "Posisi harus dipilih"),
  address: z.string().trim().min(1, "Alamat harus diisi").max(500),
  education: z.string().min(1, "Pendidikan harus dipilih"),
  major: z.string().trim().min(1, "Jurusan harus diisi").max(100),
  experience: z.string().max(1000).optional(),
  notes: z.string().max(1000).optional(),
});

const LamaranKerja = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const uploadFile = async (file: File, path: string): Promise<string | null> => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
      const filePath = `${path}/${fileName}`;

      const { error: uploadError, data } = await supabase.storage
        .from('job-applications')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('job-applications')
        .getPublicUrl(filePath);

      return publicUrl;
    } catch (error) {
      console.error('Error uploading file:', error);
      return null;
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const formData = new FormData(e.currentTarget);
      
      // Validate form data
      const data = {
        fullName: formData.get("fullName") as string,
        email: formData.get("email") as string,
        phone: formData.get("phone") as string,
        position: formData.get("position") as string,
        address: formData.get("address") as string,
        education: formData.get("education") as string,
        major: formData.get("major") as string,
        experience: formData.get("experience") as string || "",
        notes: formData.get("notes") as string || "",
      };

      // Validate with zod
      const validatedData = applicationSchema.parse(data);

      // Upload files
      let cvUrl: string | null = null;
      let coverLetterUrl: string | null = null;
      const certificateUrls: string[] = [];

      const cvFile = formData.get("cv") as File;
      if (cvFile && cvFile.size > 0) {
        cvUrl = await uploadFile(cvFile, 'cv');
        if (!cvUrl) {
          throw new Error("Gagal mengupload CV");
        }
      }

      const coverLetterFile = formData.get("coverLetter") as File;
      if (coverLetterFile && coverLetterFile.size > 0) {
        coverLetterUrl = await uploadFile(coverLetterFile, 'cover-letters');
      }

      const certificateFiles = formData.getAll("certificates") as File[];
      for (const file of certificateFiles) {
        if (file && file.size > 0) {
          const url = await uploadFile(file, 'certificates');
          if (url) certificateUrls.push(url);
        }
      }

      // Insert into database
      const { error } = await supabase
        .from("job_applications")
        .insert({
          full_name: validatedData.fullName,
          email: validatedData.email,
          phone: validatedData.phone,
          position: validatedData.position,
          address: validatedData.address,
          education: validatedData.education,
          major: validatedData.major,
          experience: validatedData.experience || null,
          notes: validatedData.notes || null,
          cv_url: cvUrl,
          cover_letter_url: coverLetterUrl,
          certificates_url: certificateUrls.length > 0 ? certificateUrls : null,
        });

      if (error) throw error;

      toast({
        title: "Lamaran Berhasil Dikirim!",
        description: "Tim HR kami akan menghubungi Anda dalam 3-5 hari kerja.",
      });
      
      (e.target as HTMLFormElement).reset();
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast({
          title: "Validasi Gagal",
          description: error.errors[0].message,
          variant: "destructive",
        });
      } else {
        console.error("Error submitting application:", error);
        toast({
          title: "Terjadi Kesalahan",
          description: error instanceof Error ? error.message : "Gagal mengirim lamaran. Silakan coba lagi.",
          variant: "destructive",
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const positions = [
    "Dokter Spesialis Jantung",
    "Perawat ICU",
    "Radiografer",
    "Apoteker",
    "Admin Pendaftaran",
    "IT Support",
    "Posisi Lainnya"
  ];

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <section className="pt-24 pb-16 px-4">
        <div className="container mx-auto max-w-3xl">
          <div className="text-center mb-8">
            <FileText className="h-16 w-16 mx-auto mb-4 text-primary" />
            <h1 className="text-4xl font-bold mb-4">Form Lamaran Kerja</h1>
            <p className="text-muted-foreground">
              Isi formulir di bawah ini untuk melamar posisi di Medica Pro
            </p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Informasi Pelamar</CardTitle>
              <CardDescription>
                Lengkapi semua informasi yang diperlukan dengan benar
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Personal Information */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Data Pribadi</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Nama Lengkap *</Label>
                      <Input id="fullName" name="fullName" required placeholder="Masukkan nama lengkap" maxLength={100} />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="email">Email *</Label>
                      <Input id="email" name="email" type="email" required placeholder="email@contoh.com" maxLength={255} />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="phone">Nomor Telepon *</Label>
                      <Input id="phone" name="phone" type="tel" required placeholder="08xxxxxxxxxx" maxLength={15} />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="position">Posisi yang Dilamar *</Label>
                      <Select name="position" required>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih posisi" />
                        </SelectTrigger>
                        <SelectContent>
                          {positions.map((position) => (
                            <SelectItem key={position} value={position}>
                              {position}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address">Alamat Lengkap *</Label>
                    <Textarea id="address" name="address" required placeholder="Masukkan alamat lengkap" rows={3} maxLength={500} />
                  </div>
                </div>

                {/* Education & Experience */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Pendidikan & Pengalaman</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="education">Pendidikan Terakhir *</Label>
                      <Select name="education" required>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih pendidikan" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="SMA/Sederajat">SMA/Sederajat</SelectItem>
                          <SelectItem value="D3">D3</SelectItem>
                          <SelectItem value="S1">S1</SelectItem>
                          <SelectItem value="S2">S2</SelectItem>
                          <SelectItem value="S3">S3</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="major">Jurusan *</Label>
                      <Input id="major" name="major" required placeholder="Masukkan jurusan" maxLength={100} />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="experience">Pengalaman Kerja</Label>
                    <Textarea 
                      id="experience"
                      name="experience"
                      placeholder="Jelaskan pengalaman kerja Anda (opsional)" 
                      rows={4}
                      maxLength={1000}
                    />
                  </div>
                </div>

                {/* Documents */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Upload Dokumen</h3>
                  
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="cv">CV/Resume *</Label>
                      <div className="border-2 border-dashed rounded-lg p-6 text-center hover:border-primary transition-colors">
                        <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                        <Input 
                          id="cv"
                          name="cv"
                          type="file" 
                          required 
                          accept=".pdf,.doc,.docx"
                          className="hidden" 
                        />
                        <Label htmlFor="cv" className="cursor-pointer">
                          <span className="text-sm text-muted-foreground">
                            Klik untuk upload CV (PDF, DOC, DOCX - Max 5MB)
                          </span>
                        </Label>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="coverLetter">Surat Lamaran</Label>
                      <div className="border-2 border-dashed rounded-lg p-6 text-center hover:border-primary transition-colors">
                        <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                        <Input 
                          id="coverLetter"
                          name="coverLetter"
                          type="file" 
                          accept=".pdf,.doc,.docx"
                          className="hidden" 
                        />
                        <Label htmlFor="coverLetter" className="cursor-pointer">
                          <span className="text-sm text-muted-foreground">
                            Klik untuk upload Surat Lamaran (Opsional)
                          </span>
                        </Label>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="certificates">Sertifikat/Ijazah Pendukung</Label>
                      <div className="border-2 border-dashed rounded-lg p-6 text-center hover:border-primary transition-colors">
                        <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                        <Input 
                          id="certificates"
                          name="certificates"
                          type="file" 
                          accept=".pdf,.jpg,.jpeg,.png"
                          className="hidden"
                          multiple
                        />
                        <Label htmlFor="certificates" className="cursor-pointer">
                          <span className="text-sm text-muted-foreground">
                            Klik untuk upload Sertifikat (Opsional)
                          </span>
                        </Label>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Additional Notes */}
                <div className="space-y-2">
                  <Label htmlFor="notes">Catatan Tambahan</Label>
                  <Textarea 
                    id="notes"
                    name="notes"
                    placeholder="Informasi tambahan yang ingin Anda sampaikan (opsional)" 
                    rows={4}
                    maxLength={1000}
                  />
                </div>

                <div className="flex gap-4">
                  <Button type="submit" className="flex-1" disabled={isSubmitting}>
                    {isSubmitting ? "Mengirim..." : "Kirim Lamaran"}
                  </Button>
                  <Button type="button" variant="outline" onClick={() => window.history.back()}>
                    Kembali
                  </Button>
                </div>

                <p className="text-sm text-muted-foreground text-center">
                  Dengan mengirimkan formulir ini, Anda menyetujui bahwa data Anda akan diproses sesuai dengan kebijakan privasi kami.
                </p>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default LamaranKerja;
