import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Clock, 
  Phone, 
  MapPin, 
  Calendar, 
  Ambulance,
  FileText,
  CreditCard,
  Users
} from "lucide-react";

const Informasi = () => {
  const infoCards = [
    {
      icon: Clock,
      title: "Jam Operasional",
      items: [
        "Senin - Jumat: 08:00 - 20:00",
        "Sabtu: 08:00 - 16:00",
        "Minggu: 08:00 - 14:00",
        "IGD: 24 Jam (Setiap Hari)"
      ]
    },
    {
      icon: Calendar,
      title: "Cara Pendaftaran",
      items: [
        "Online: Melalui website resmi",
        "Telepon: +1 (555) 123-4567",
        "WhatsApp: +1 (555) 123-4568",
        "Datang langsung ke loket pendaftaran"
      ]
    },
    {
      icon: Ambulance,
      title: "Layanan Darurat",
      items: [
        "Hotline Darurat: +1 (555) 911-0000",
        "Ambulans 24/7",
        "Tim Medis Siaga",
        "Helipad untuk kasus kritis"
      ]
    },
    {
      icon: FileText,
      title: "Dokumen yang Diperlukan",
      items: [
        "Kartu identitas (KTP/Paspor)",
        "Kartu asuransi (jika ada)",
        "Rujukan dokter (untuk spesialis)",
        "Riwayat medis sebelumnya"
      ]
    },
    {
      icon: CreditCard,
      title: "Metode Pembayaran",
      items: [
        "Tunai (Cash)",
        "Kartu Kredit/Debit",
        "Transfer Bank",
        "Asuransi Kesehatan"
      ]
    },
    {
      icon: Users,
      title: "Fasilitas Pasien",
      items: [
        "Ruang tunggu nyaman ber-AC",
        "Wi-Fi gratis",
        "Kafeteria & Apotek 24 jam",
        "Area parkir luas"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-primary/10 via-background to-secondary/10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-6">
              Informasi Penting
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground">
              Semua yang perlu Anda ketahui tentang layanan, jam operasional, 
              dan prosedur di Medica Pro.
            </p>
          </div>
        </div>
      </section>

      {/* Information Cards */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {infoCards.map((card, index) => (
              <Card 
                key={index}
                className="p-8 hover:shadow-[var(--shadow-lg)] transition-all duration-300 hover:-translate-y-1"
              >
                <div className="w-14 h-14 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mb-6">
                  <card.icon className="h-7 w-7 text-primary-foreground" />
                </div>
                <h3 className="text-xl font-bold text-card-foreground mb-4">{card.title}</h3>
                <ul className="space-y-2">
                  {card.items.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-muted-foreground">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="p-8 md:p-12 max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-card-foreground mb-4">
              Butuh Bantuan Lebih Lanjut?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Tim customer service kami siap membantu Anda dengan pertanyaan atau kebutuhan khusus.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="default">
                <Phone className="mr-2 h-5 w-5" />
                Hubungi Kami
              </Button>
              <Button size="lg" variant="outline">
                <MapPin className="mr-2 h-5 w-5" />
                Lihat Lokasi
              </Button>
            </div>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Informasi;
