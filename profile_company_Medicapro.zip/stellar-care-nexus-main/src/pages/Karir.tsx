import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Briefcase, Users, TrendingUp, Heart, Clock, Award } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Karir = () => {
  const navigate = useNavigate();
  
  const benefits = [
    {
      icon: Heart,
      title: "Lingkungan Kerja Positif",
      description: "Budaya kerja yang mendukung kolaborasi dan pengembangan profesional"
    },
    {
      icon: TrendingUp,
      title: "Pengembangan Karir",
      description: "Program pelatihan dan kesempatan untuk berkembang dalam karir medis"
    },
    {
      icon: Award,
      title: "Kompensasi Kompetitif",
      description: "Gaji dan benefit yang sesuai dengan standar industri kesehatan"
    },
    {
      icon: Users,
      title: "Tim Profesional",
      description: "Bekerja bersama tim medis yang berpengalaman dan berdedikasi"
    }
  ];

  const openings = [
    {
      title: "Dokter Spesialis Jantung",
      department: "Kardiologi",
      type: "Full Time",
      requirements: [
        "Memiliki STR yang masih berlaku",
        "Pengalaman minimal 3 tahun",
        "Mampu bekerja dalam tim"
      ]
    },
    {
      title: "Perawat ICU",
      department: "Intensive Care Unit",
      type: "Full Time",
      requirements: [
        "D3/S1 Keperawatan",
        "Memiliki sertifikat BTCLS/ACLS",
        "Pengalaman di ICU minimal 1 tahun"
      ]
    },
    {
      title: "Radiografer",
      department: "Radiologi",
      type: "Full Time",
      requirements: [
        "D3 Teknik Radiodiagnostik",
        "Memiliki STR aktif",
        "Menguasai operasional alat radiologi"
      ]
    },
    {
      title: "Apoteker",
      department: "Farmasi",
      type: "Full Time",
      requirements: [
        "S1 Farmasi + Profesi Apoteker",
        "Memiliki STRA yang masih berlaku",
        "Pengalaman minimal 2 tahun"
      ]
    },
    {
      title: "Admin Pendaftaran",
      department: "Front Office",
      type: "Full Time",
      requirements: [
        "Minimal D3 semua jurusan",
        "Komunikatif dan ramah",
        "Menguasai Microsoft Office"
      ]
    },
    {
      title: "IT Support",
      department: "IT & Teknologi",
      type: "Full Time",
      requirements: [
        "D3/S1 Teknik Informatika",
        "Pengalaman troubleshooting hardware/software",
        "Memahami sistem informasi rumah sakit"
      ]
    }
  ];

  return (
    <div className="min-h-screen">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 px-4 bg-gradient-to-b from-primary/5 to-background">
        <div className="container mx-auto text-center">
          <Briefcase className="h-16 w-16 mx-auto mb-6 text-primary" />
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Karir di Medica Pro
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Bergabunglah dengan tim kami dan jadilah bagian dari perubahan dalam pelayanan kesehatan
          </p>
        </div>
      </section>

      {/* Why Join Us */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">
            Mengapa Bergabung dengan Kami?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <benefit.icon className="h-12 w-12 mx-auto mb-4 text-primary" />
                  <CardTitle className="text-xl">{benefit.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>{benefit.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Current Openings */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-4">
            Lowongan Tersedia
          </h2>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            Temukan posisi yang sesuai dengan keahlian dan minat Anda
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {openings.map((job, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <Briefcase className="h-8 w-8 text-primary" />
                    <span className="text-xs bg-primary/10 text-primary px-3 py-1 rounded-full">
                      {job.type}
                    </span>
                  </div>
                  <CardTitle className="text-xl">{job.title}</CardTitle>
                  <CardDescription className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    {job.department}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <h4 className="font-semibold mb-2 text-sm">Persyaratan:</h4>
                  <ul className="space-y-1 mb-4">
                    {job.requirements.map((req, idx) => (
                      <li key={idx} className="text-sm text-muted-foreground flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>{req}</span>
                      </li>
                    ))}
                  </ul>
                  <Button className="w-full" onClick={() => navigate('/lamaran-kerja')}>Lamar Sekarang</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Application Process */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold text-center mb-12">
            Proses Rekrutmen
          </h2>
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-bold">1</span>
                  Kirim Lamaran
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Kirimkan CV dan surat lamaran Anda melalui email atau form online yang tersedia
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-bold">2</span>
                  Seleksi Administrasi
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Tim HR kami akan meninjau berkas lamaran dan menghubungi kandidat yang memenuhi syarat
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-bold">3</span>
                  Wawancara
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Tahap wawancara dengan tim HR dan user untuk mengevaluasi kompetensi dan kesesuaian
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-bold">4</span>
                  Offering & Onboarding
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Kandidat terpilih akan menerima tawaran kerja dan mengikuti program onboarding
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="mt-12 text-center">
            <Card className="bg-primary/5 border-primary/20">
              <CardHeader>
                <CardTitle>Tertarik Bergabung?</CardTitle>
                <CardDescription>
                  Kirimkan lamaran Anda ke email kami atau hubungi departemen HR
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-col items-center gap-2">
                  <p className="text-sm font-medium">Email: karir@globalhospital.com</p>
                  <p className="text-sm font-medium">Telp: (021) 1234-5678 ext. 100</p>
                </div>
                <Button size="lg" onClick={() => navigate('/lamaran-kerja')}>Kirim Lamaran</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Karir;
