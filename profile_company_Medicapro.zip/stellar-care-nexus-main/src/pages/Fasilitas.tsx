import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Card } from "@/components/ui/card";
import { 
  Building2, 
  Bed, 
  Microscope, 
  Heart, 
  Stethoscope,
  Pill,
  Scan,
  Syringe,
  Activity,
  Users,
  Utensils,
  ParkingCircle
} from "lucide-react";

const Fasilitas = () => {
  const facilities = [
    {
      icon: Building2,
      title: "Ruang Rawat Inap",
      description: "Kamar VIP, Suite, dan kelas standar dengan fasilitas lengkap dan nyaman untuk pemulihan optimal.",
      features: ["AC & TV", "Kamar Mandi Pribadi", "WiFi Gratis", "Tempat Tidur Pendamping"]
    },
    {
      icon: Bed,
      title: "Unit Gawat Darurat",
      description: "Layanan IGD 24/7 dengan tim medis berpengalaman dan peralatan canggih untuk penanganan cepat.",
      features: ["Buka 24 Jam", "Tim Siaga", "Ambulans", "Helipad"]
    },
    {
      icon: Microscope,
      title: "Laboratorium",
      description: "Laboratorium modern dengan teknologi terkini untuk pemeriksaan diagnostik yang akurat dan cepat.",
      features: ["Tes Darah", "Mikrobiologi", "Patologi", "Hasil Cepat"]
    },
    {
      icon: Scan,
      title: "Radiologi & Imaging",
      description: "Fasilitas pencitraan medis lengkap termasuk MRI, CT Scan, X-Ray, dan USG dengan teknologi terbaru.",
      features: ["MRI 3 Tesla", "CT Scan 128 Slice", "Ultrasound 4D", "Mammografi Digital"]
    },
    {
      icon: Heart,
      title: "Pusat Jantung",
      description: "Layanan komprehensif untuk kesehatan jantung dengan dokter spesialis dan teknologi kardiovaskular terkini.",
      features: ["Kateterisasi", "Echocardiography", "EKG", "Stress Test"]
    },
    {
      icon: Stethoscope,
      title: "Poliklinik Spesialis",
      description: "Lebih dari 150 spesialisasi medis dengan dokter berpengalaman untuk berbagai kebutuhan kesehatan.",
      features: ["150+ Spesialisasi", "Konsultasi", "Pemeriksaan", "Follow-up"]
    },
    {
      icon: Syringe,
      title: "Ruang Operasi",
      description: "Ruang operasi modern dengan standar internasional dan tim bedah berpengalaman.",
      features: ["8 Ruang Operasi", "Teknologi Canggih", "Sterilisasi Maksimal", "ICU Terintegrasi"]
    },
    {
      icon: Activity,
      title: "ICU & NICU",
      description: "Unit perawatan intensif dengan monitoring 24/7 dan peralatan life support terlengkap.",
      features: ["Monitoring 24/7", "Ventilator", "Tim Intensivis", "NICU untuk Bayi"]
    },
    {
      icon: Pill,
      title: "Apotek 24 Jam",
      description: "Apotek dengan stok lengkap obat-obatan dan produk kesehatan, buka 24 jam setiap hari.",
      features: ["Buka 24 Jam", "Stok Lengkap", "Konsultasi Apoteker", "Delivery"]
    },
    {
      icon: Users,
      title: "Fisioterapi",
      description: "Pusat rehabilitasi medis dengan fisioterapis profesional dan peralatan terapi modern.",
      features: ["Terapi Manual", "Elektroterapi", "Hidroterapi", "Program Rehabilitasi"]
    },
    {
      icon: Utensils,
      title: "Kafeteria & Restoran",
      description: "Fasilitas makanan dan minuman dengan menu sehat dan bergizi untuk pasien dan pengunjung.",
      features: ["Menu Sehat", "Halal", "Diet Khusus", "Buka Pagi-Malam"]
    },
    {
      icon: ParkingCircle,
      title: "Parkir & Transportasi",
      description: "Area parkir luas dengan keamanan 24 jam dan layanan valet parking untuk kenyamanan Anda.",
      features: ["Parkir Luas", "Keamanan 24/7", "Valet Parking", "Akses Mudah"]
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-primary/10 via-background to-secondary/10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-block px-4 py-2 bg-card/80 backdrop-blur-sm rounded-full mb-6 border border-border">
              <span className="text-primary font-semibold">Fasilitas Kelas Dunia</span>
            </div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-6">
              Fasilitas Lengkap untuk Kesehatan Anda
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground">
              Dilengkapi dengan teknologi medis terkini dan tim profesional berpengalaman 
              untuk memberikan pelayanan kesehatan terbaik.
            </p>
          </div>
        </div>
      </section>

      {/* Facilities Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {facilities.map((facility, index) => (
              <Card 
                key={index}
                className="p-8 hover:shadow-[var(--shadow-lg)] transition-all duration-300 hover:-translate-y-1 group"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <facility.icon className="h-8 w-8 text-primary-foreground" />
                </div>
                <h3 className="text-xl font-bold text-card-foreground mb-3">{facility.title}</h3>
                <p className="text-muted-foreground mb-4 leading-relaxed">{facility.description}</p>
                <div className="space-y-2">
                  {facility.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-br from-primary via-primary to-secondary">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-primary-foreground mb-6">
              Kunjungi Fasilitas Kami
            </h2>
            <p className="text-lg sm:text-xl text-primary-foreground/90 mb-8">
              Tim kami siap memberikan tur fasilitas dan menjawab pertanyaan Anda tentang layanan kesehatan kami.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href="tel:+15551234567"
                className="inline-flex items-center justify-center gap-2 bg-secondary hover:bg-secondary/90 text-secondary-foreground px-8 py-4 rounded-lg font-semibold shadow-lg transition-all hover:shadow-xl hover:-translate-y-0.5 text-lg"
              >
                <Stethoscope className="h-5 w-5" />
                Hubungi Kami
              </a>
              <a 
                href="https://maps.app.goo.gl/yhhYT4rafeozcT176"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 bg-primary-foreground/10 hover:bg-primary-foreground/20 text-primary-foreground border-2 border-primary-foreground/30 px-8 py-4 rounded-lg font-semibold transition-all hover:-translate-y-0.5 text-lg"
              >
                <Building2 className="h-5 w-5" />
                Lihat Lokasi
              </a>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Fasilitas;