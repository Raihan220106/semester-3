-- Schema setup for PL/pgSQL lesson (pertemuan 3)
-- This creates all tables and data needed for the examples

-- Clean up existing tables if they exist
DROP TABLE IF EXISTS enrollments CASCADE;
DROP TABLE IF EXISTS students CASCADE;
DROP TABLE IF EXISTS courses CASCADE;
DROP FUNCTION IF EXISTS grade_points(TEXT);

-- Create students table
CREATE TABLE students (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    first_name TEXT,
    last_name TEXT,
    email TEXT UNIQUE,
    birth_date DATE,
    gpa NUMERIC(3,2),
    active BOOLEAN DEFAULT TRUE
);

-- Create courses table  
CREATE TABLE courses (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    credits INTEGER NOT NULL
);

-- Create enrollments table
CREATE TABLE enrollments (
    student_id INTEGER REFERENCES students(id),
    course_id INTEGER REFERENCES courses(id),
    grade TEXT,
    semester TEXT,
    PRIMARY KEY (student_id, course_id, semester)
);

-- Create grade_points function
CREATE OR REPLACE FUNCTION grade_points(grade TEXT)
RETURNS NUMERIC LANGUAGE plpgsql AS $$
BEGIN
    RETURN CASE UPPER(grade)
        WHEN 'A' THEN 4.0
        WHEN 'B' THEN 3.0
        WHEN 'C' THEN 2.0
        WHEN 'D' THEN 1.0
        WHEN 'F' THEN 0.0
        ELSE 0.0
    END;
END;
$$;

-- Insert sample students
INSERT INTO students (id, name, first_name, last_name, email, birth_date, gpa, active) VALUES
(1, 'Ahmad Sutrisno', 'Ahmad', 'Sutrisno', 'ahmad@university.edu', '1995-08-15', 3.75, TRUE),
(2, 'Siti Nurhaliza', 'Siti', 'Nurhaliza', 'siti@university.edu', '1996-03-20', 3.50, TRUE),
(3, 'Budi Santoso', 'Budi', 'Santoso', 'budi@university.edu', '1995-12-10', 2.25, FALSE),
(4, 'Rina Wati', 'Rina', 'Wati', 'rina@university.edu', '1997-07-05', 3.85, TRUE);

-- Insert sample courses
INSERT INTO courses (id, name, credits) VALUES
(1, 'Database Systems', 3),
(2, 'Programming Fundamentals', 4),
(3, 'Data Structures', 3),
(4, 'Web Development', 2);

-- Insert sample enrollments
INSERT INTO enrollments (student_id, course_id, grade, semester) VALUES
(1, 1, 'A', '2023-1'),
(1, 2, 'B', '2023-1'),
(2, 1, 'B', '2023-1'),
(2, 3, 'A', '2023-1'),
(3, 2, 'C', '2023-1'),
(4, 1, 'A', '2023-1'),
(4, 4, 'A', '2023-1');

-- Verify setup
SELECT 'Students' as table_name, COUNT(*) as row_count FROM students
UNION ALL
SELECT 'Courses', COUNT(*) FROM courses  
UNION ALL
SELECT 'Enrollments', COUNT(*) FROM enrollments;

-- Confirmation message
DO $$
BEGIN
    RAISE NOTICE 'Schema setup completed successfully!';
END;
$$;