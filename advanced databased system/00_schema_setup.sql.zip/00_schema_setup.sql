-- Trigger 00: schema_setup (Database Schema Setup for Triggers)
-- Script ini menyiapkan schema database untuk demonstrasi triggers dan audit systems
-- Demonstrates: Table creation, audit table design, index optimization, trigger cleanup
DROP TRIGGER IF EXISTS trg_validate_student ON students CASCADE;
DROP TRIGGER IF EXISTS trg_audit_student ON students CASCADE;
DROP TRIGGER IF EXISTS trg_timestamps_students ON students CASCADE;
DROP TRIGGER IF EXISTS audit_students ON students CASCADE;
DROP TRIGGER IF EXISTS audit_courses ON courses CASCADE;

DROP FUNCTION IF EXISTS validate_student_data() CASCADE;
DROP FUNCTION IF EXISTS audit_student_changes() CASCADE;
DROP FUNCTION IF EXISTS setup_defaults() CASCADE;
DROP FUNCTION IF EXISTS track_updates() CASCADE;
DROP FUNCTION IF EXISTS soft_delete() CASCADE;
DROP FUNCTION IF EXISTS log_new_student() CASCADE;
DROP FUNCTION IF EXISTS track_gpa_changes() CASCADE;
DROP FUNCTION IF EXISTS archive_deleted_student() CASCADE;
DROP FUNCTION IF EXISTS track_field_changes() CASCADE;
DROP FUNCTION IF EXISTS handle_null_changes() CASCADE;
DROP FUNCTION IF EXISTS smart_notification_trigger() CASCADE;
DROP FUNCTION IF EXISTS student_audit() CASCADE;
DROP FUNCTION IF EXISTS smart_trigger() CASCADE;
DROP FUNCTION IF EXISTS universal_trigger() CASCADE;
DROP FUNCTION IF EXISTS timing_trigger() CASCADE;
DROP FUNCTION IF EXISTS universal_audit() CASCADE;
DROP FUNCTION IF EXISTS maintain_timestamps() CASCADE;
DROP FUNCTION IF EXISTS capture_user_context() CASCADE;
DROP FUNCTION IF EXISTS track_important_changes() CASCADE;
DROP FUNCTION IF EXISTS cleanup_old_audit() CASCADE;
DROP FUNCTION IF EXISTS audit_report() CASCADE;

-- Drop tables
DROP TABLE IF EXISTS audit_log_202401 CASCADE;
DROP TABLE IF EXISTS audit_log_monthly CASCADE;
DROP TABLE IF EXISTS universal_audit CASCADE;
DROP TABLE IF EXISTS field_audit CASCADE;
DROP TABLE IF EXISTS critical_changes CASCADE;
DROP TABLE IF EXISTS change_log CASCADE;
DROP TABLE IF EXISTS status_history CASCADE;
DROP TABLE IF EXISTS notifications CASCADE;
DROP TABLE IF EXISTS contact_changes CASCADE;
DROP TABLE IF EXISTS field_changes CASCADE;
DROP TABLE IF EXISTS students_archive CASCADE;
DROP TABLE IF EXISTS gpa_history CASCADE;
DROP TABLE IF EXISTS registration_log CASCADE;
DROP TABLE IF EXISTS students_audit CASCADE;
DROP TABLE IF EXISTS audit_log CASCADE;
DROP TABLE IF EXISTS courses CASCADE;
DROP TABLE IF EXISTS students CASCADE;

-- Create main tables
CREATE TABLE students (
    id SERIAL PRIMARY KEY,
    nim VARCHAR(10) UNIQUE NOT NULL,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    gpa DECIMAL(3,2) CHECK (gpa >= 0 AND gpa <= 4.0),
    status VARCHAR(20) DEFAULT 'ACTIVE',
    alamat TEXT,
    protected BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE,
    created_by TEXT,
    updated_at TIMESTAMP WITH TIME ZONE,
    updated_by TEXT,
    deleted_at TIMESTAMP WITH TIME ZONE,
    version INTEGER DEFAULT 0
);

CREATE TABLE courses (
    id SERIAL PRIMARY KEY,
    kode VARCHAR(10) UNIQUE NOT NULL,
    nama VARCHAR(100) NOT NULL,
    sks INTEGER NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Audit tables
CREATE TABLE audit_log (
    id BIGSERIAL PRIMARY KEY,
    table_name TEXT NOT NULL,
    record_id TEXT NOT NULL,
    operation TEXT NOT NULL CHECK (operation IN ('INSERT', 'UPDATE', 'DELETE')),
    occurred_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    user_name TEXT DEFAULT current_user,
    old_values JSONB,
    new_values JSONB,
    changed_fields TEXT[]
);

CREATE TABLE students_audit (
    audit_id BIGSERIAL PRIMARY KEY,
    student_id INTEGER NOT NULL,
    operation CHAR(1) CHECK (operation IN ('I', 'U', 'D')),
    audit_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    audit_user TEXT DEFAULT current_user,
    nim VARCHAR(10),
    nama VARCHAR(100),
    email VARCHAR(100),
    gpa DECIMAL(3,2),
    status VARCHAR(20)
);

CREATE TABLE registration_log (
    id SERIAL PRIMARY KEY,
    student_nim VARCHAR(10),
    student_name VARCHAR(100),
    registration_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE gpa_history (
    id SERIAL PRIMARY KEY,
    student_nim VARCHAR(10),
    old_gpa DECIMAL(3,2),
    new_gpa DECIMAL(3,2),
    change_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE students_archive (
    id SERIAL PRIMARY KEY,
    original_id INTEGER,
    nim VARCHAR(10),
    nama VARCHAR(100),
    gpa DECIMAL(3,2),
    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE field_changes (
    id SERIAL PRIMARY KEY,
    table_name TEXT,
    record_id INTEGER,
    field_name TEXT,
    old_value TEXT,
    new_value TEXT,
    changed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE contact_changes (
    id SERIAL PRIMARY KEY,
    student_id INTEGER,
    field_name TEXT,
    old_value TEXT,
    new_value TEXT,
    change_type TEXT,
    changed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notifications (
    id SERIAL PRIMARY KEY,
    student_id INTEGER,
    message TEXT,
    priority VARCHAR(10),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE status_history (
    id SERIAL PRIMARY KEY,
    student_id INTEGER,
    old_status VARCHAR(20),
    new_status VARCHAR(20),
    change_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE change_log (
    id SERIAL PRIMARY KEY,
    table_name TEXT,
    operation TEXT,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE critical_changes (
    id SERIAL PRIMARY KEY,
    table_name TEXT,
    record_id INTEGER,
    field_name TEXT,
    old_value TEXT,
    new_value TEXT,
    detected_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE field_audit (
    id SERIAL PRIMARY KEY,
    table_name TEXT,
    record_id INTEGER,
    changes JSONB,
    changed_by TEXT,
    changed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE universal_audit (
    id BIGSERIAL PRIMARY KEY,
    table_name TEXT NOT NULL,
    operation TEXT NOT NULL,
    record_id INTEGER,
    audit_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Essential indexes
CREATE INDEX idx_audit_table_time ON audit_log (table_name, occurred_at);
CREATE INDEX idx_audit_record ON audit_log (table_name, record_id);
CREATE INDEX idx_audit_user ON audit_log (user_name, occurred_at);

-- Partition audit table untuk performance (will be used later)
-- Note: Skipping partitioned table karena PRIMARY KEY constraint requirement

COMMENT ON TABLE students IS 'Main students table with trigger examples';
COMMENT ON TABLE audit_log IS 'Universal audit trail for all tables';
COMMENT ON TABLE students_audit IS 'Dedicated audit table for students';

-- Trigger 01: sample_data (Sample Data for Trigger Testing)
-- Script ini menyiapkan sample data untuk testing berbagai jenis triggers
-- Demonstrates: Data insertion strategies, trigger testing scenarios, data variety
INSERT INTO courses (kode, nama, sks) VALUES
('IF101', 'Pemrograman Dasar', 3),
('IF201', 'Basis Data', 3),
('IF301', 'Algoritma Lanjut', 4),
('SI101', 'Sistem Informasi', 3),
('SI201', 'Analisis Sistem', 3);

-- Insert sample students (akan trigger various functions)
-- Note: beberapa insert akan trigger validation dan audit functions
INSERT INTO students (nim, nama, email, gpa, status) VALUES
('2021001', 'ahmad sutrisno', 'AHMAD@EMAIL.COM', 3.50, 'ACTIVE'),
('2021002', 'siti nurhaliza', NULL, 3.75, 'ACTIVE'),
('2021003', 'budi santoso', 'budi@email.com', 2.80, 'ACTIVE');

-- Data untuk testing updates (akan trigger change tracking)
INSERT INTO students (nim, nama, email, gpa, status, alamat) VALUES
('2021004', 'DEWI SARTIKA', 'dewi@email.com', 3.20, 'ACTIVE', 'Jl. Merdeka No. 123, Jakarta'),
('2021005', 'eko prasetyo', 'eko@email.com', 3.90, 'ACTIVE', 'Jl. Sudirman No. 45'),
('2021006', 'farah dilla', 'farah@email.com', 2.50, 'PROBATION', 'Short'),  -- Will trigger alamat validation
('2021007', 'gilang ramadhan', 'gilang@email.com', 3.85, 'ACTIVE', 'Jl. Gatot Subroto No. 789, Surabaya'),
('2021008', 'hana permata', NULL, 3.45, 'ACTIVE', 'Jl. Diponegoro No. 321, Bandung');

COMMENT ON TABLE students IS 'Sample data includes various scenarios for trigger testing';
COMMENT ON TABLE courses IS 'Basic course data for reference';